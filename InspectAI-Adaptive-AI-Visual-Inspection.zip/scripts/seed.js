const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

// High quality realistic simulated PCB images with circuit tracks, components, chips & inspection overlays
// We generate SVG data URIs so that they render crisp, offline, instantly and 100% reliably without external internet dependency
function generatePcbSvg({ defectType = 'None', location = 'None', label = 'Normal', isPass = true }) {
  const boxColor = isPass ? '#22c55e' : '#ef4444';
  const boxBg = isPass ? 'rgba(34, 197, 94, 0.15)' : 'rgba(239, 68, 68, 0.18)';
  
  let boxX = 320, boxY = 160, boxW = 140, boxH = 100;
  if (location === 'Top Right') { boxX = 460; boxY = 60; boxW = 120; boxH = 90; }
  else if (location === 'Top Left') { boxX = 60; boxY = 60; boxW = 130; boxH = 95; }
  else if (location === 'Center') { boxX = 260; boxY = 150; boxW = 160; boxH = 110; }
  else if (location === 'Bottom Right') { boxX = 450; boxY = 240; boxW = 130; boxH = 90; }
  else if (location === 'Bottom Left') { boxX = 70; boxY = 230; boxW = 120; boxH = 90; }

  const defectVisual = !isPass ? `
    <!-- Defect Visual Artifact -->
    ${defectType === 'Missing Component' ? `
      <rect x="${boxX + 25}" y="${boxY + 20}" width="50" height="40" fill="#1e293b" stroke="#f43f5e" stroke-width="2" stroke-dasharray="4,4"/>
      <line x1="${boxX + 20}" y1="${boxY + 15}" x2="${boxX + 80}" y2="${boxY + 65}" stroke="#ef4444" stroke-width="2"/>
      <line x1="${boxX + 80}" y1="${boxY + 15}" x2="${boxX + 20}" y2="${boxY + 65}" stroke="#ef4444" stroke-width="2"/>
      <circle cx="${boxX + 25}" cy="${boxY + 20}" r="3" fill="#cbd5e1"/>
      <circle cx="${boxX + 75}" cy="${boxY + 20}" r="3" fill="#cbd5e1"/>
      <circle cx="${boxX + 25}" cy="${boxY + 60}" r="3" fill="#cbd5e1"/>
      <circle cx="${boxX + 75}" cy="${boxY + 60}" r="3" fill="#cbd5e1"/>
    ` : defectType === 'Scratch' ? `
      <path d="M ${boxX + 15} ${boxY + 70} Q ${boxX + 60} ${boxY + 30} ${boxX + 105} ${boxY + 20}" stroke="#fbbf24" stroke-width="3" fill="none" stroke-linecap="round"/>
      <path d="M ${boxX + 25} ${boxY + 75} Q ${boxX + 65} ${boxY + 40} ${boxX + 100} ${boxY + 25}" stroke="#f87171" stroke-width="2" fill="none"/>
    ` : defectType === 'Crack' ? `
      <path d="M ${boxX + 30} ${boxY + 15} L ${boxX + 50} ${boxY + 45} L ${boxX + 45} ${boxY + 60} L ${boxX + 75} ${boxY + 80}" stroke="#ef4444" stroke-width="3" fill="none"/>
    ` : defectType === 'Misalignment' ? `
      <rect x="${boxX + 30}" y="${boxY + 20}" width="50" height="40" rx="3" fill="#334155" stroke="#f59e0b" stroke-width="2" transform="rotate(14 ${boxX + 55} ${boxY + 40})"/>
    ` : `
      <ellipse cx="${boxX + 55}" cy="${boxY + 45}" rx="30" ry="20" fill="rgba(244,63,94,0.3)" stroke="#ef4444" stroke-width="2"/>
    `}
  ` : '';

  const svgString = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 360" width="640" height="360">
    <defs>
      <linearGradient id="pcbBg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#064e3b" />
        <stop offset="100%" stop-color="#022c22" />
      </linearGradient>
      <linearGradient id="chipGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#1e293b" />
        <stop offset="100%" stop-color="#0f172a" />
      </linearGradient>
      <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
        <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(16,185,129,0.08)" stroke-width="1"/>
      </pattern>
    </defs>
    
    <!-- PCB Board Base -->
    <rect width="640" height="360" fill="#0b1320"/>
    <rect x="20" y="20" width="600" height="320" rx="12" fill="url(#pcbBg)" stroke="#059669" stroke-width="3"/>
    <rect x="20" y="20" width="600" height="320" rx="12" fill="url(#grid)"/>

    <!-- Mounting Holes -->
    <circle cx="45" cy="45" r="8" fill="#0f172a" stroke="#d97706" stroke-width="3"/>
    <circle cx="595" cy="45" r="8" fill="#0f172a" stroke="#d97706" stroke-width="3"/>
    <circle cx="45" cy="315" r="8" fill="#0f172a" stroke="#d97706" stroke-width="3"/>
    <circle cx="595" cy="315" r="8" fill="#0f172a" stroke="#d97706" stroke-width="3"/>

    <!-- Copper Circuit Tracks -->
    <g stroke="#10b981" stroke-width="2" fill="none" opacity="0.75">
      <path d="M 60 120 L 140 120 L 170 150 L 260 150"/>
      <path d="M 60 140 L 130 140 L 160 170 L 260 170"/>
      <path d="M 60 160 L 120 160 L 150 190 L 260 190"/>
      <path d="M 420 160 L 480 160 L 520 120 L 570 120"/>
      <path d="M 420 180 L 490 180 L 530 220 L 570 220"/>
      <path d="M 320 80 L 320 140"/>
      <path d="M 340 80 L 340 140"/>
      <path d="M 360 80 L 360 140"/>
      <path d="M 320 260 L 320 300"/>
      <path d="M 360 260 L 360 300"/>
    </g>

    <!-- Soldering Pads & Vias -->
    <g fill="#d97706" stroke="#b45309" stroke-width="1">
      <circle cx="140" cy="80" r="3"/>
      <circle cx="155" cy="80" r="3"/>
      <circle cx="170" cy="80" r="3"/>
      <circle cx="185" cy="80" r="3"/>
      <circle cx="480" cy="80" r="3"/>
      <circle cx="495" cy="80" r="3"/>
      <circle cx="510" cy="80" r="3"/>
      <circle cx="480" cy="270" r="3"/>
      <circle cx="495" cy="270" r="3"/>
      <circle cx="510" cy="270" r="3"/>
    </g>

    <!-- Major IC Main Controller Chip -->
    <rect x="270" y="145" width="100" height="90" rx="4" fill="url(#chipGrad)" stroke="#334155" stroke-width="2"/>
    <circle cx="282" cy="157" r="3" fill="#64748b"/>
    <text x="320" y="188" fill="#94a3b8" font-family="monospace" font-size="10" font-weight="bold" text-anchor="middle">INSPECT-AI</text>
    <text x="320" y="202" fill="#64748b" font-family="monospace" font-size="8" text-anchor="middle">STM32-ARM64</text>
    
    <!-- IC Pins -->
    <g fill="#94a3b8">
      <!-- Top pins -->
      <rect x="280" y="137" width="4" height="8"/>
      <rect x="295" y="137" width="4" height="8"/>
      <rect x="310" y="137" width="4" height="8"/>
      <rect x="325" y="137" width="4" height="8"/>
      <rect x="340" y="137" width="4" height="8"/>
      <rect x="355" y="137" width="4" height="8"/>
      <!-- Bottom pins -->
      <rect x="280" y="235" width="4" height="8"/>
      <rect x="295" y="235" width="4" height="8"/>
      <rect x="310" y="235" width="4" height="8"/>
      <rect x="325" y="235" width="4" height="8"/>
      <rect x="340" y="235" width="4" height="8"/>
      <rect x="355" y="235" width="4" height="8"/>
    </g>

    <!-- Discrete SMD Components -->
    <!-- Capacitors -->
    <rect x="180" y="90" width="16" height="28" rx="2" fill="#b45309" stroke="#78350f" stroke-width="1"/>
    <rect x="210" y="90" width="16" height="28" rx="2" fill="#b45309" stroke="#78350f" stroke-width="1"/>
    <rect x="440" y="240" width="28" height="14" rx="2" fill="#0284c7" stroke="#0369a1" stroke-width="1"/>
    <rect x="120" y="240" width="28" height="14" rx="2" fill="#334155" stroke="#1e293b" stroke-width="1"/>
    <rect x="160" y="240" width="28" height="14" rx="2" fill="#334155" stroke="#1e293b" stroke-width="1"/>

    <!-- Silkscreen Text Labels -->
    <text x="70" y="55" fill="#f8fafc" font-family="monospace" font-size="11" font-weight="bold">INSPECT-UNIT-01</text>
    <text x="70" y="70" fill="#a7f3d0" font-family="sans-serif" font-size="8">REV 4.2 / INDUSTRIAL IoT</text>
    <text x="500" y="325" fill="#6ee7b7" font-family="monospace" font-size="9">PASS QC-A4</text>

    ${defectVisual}

    <!-- AI Bounding Box Overlay -->
    <rect x="${boxX}" y="${boxY}" width="${boxW}" height="${boxH}" fill="${boxBg}" stroke="${boxColor}" stroke-width="2.5" stroke-dasharray="${isPass ? 'none' : '6,3'}" rx="4"/>
    
    <!-- AI Tag Pill -->
    <rect x="${boxX}" y="${boxY - 22}" width="${Math.max(label.length * 8 + 20, 95)}" height="22" rx="3" fill="${boxColor}"/>
    <text x="${boxX + 8}" y="${boxY - 7}" fill="#ffffff" font-family="sans-serif" font-size="11" font-weight="bold">${label}</text>

    <!-- Crosshair Target -->
    <g stroke="${boxColor}" stroke-width="1" opacity="0.8">
      <line x1="${boxX + boxW/2 - 10}" y1="${boxY + boxH/2}" x2="${boxX + boxW/2 + 10}" y2="${boxY + boxH/2}"/>
      <line x1="${boxX + boxW/2}" y1="${boxY + boxH/2 - 10}" x2="${boxX + boxW/2}" y2="${boxY + boxH/2 + 10}"/>
      <circle cx="${boxX + boxW/2}" cy="${boxY + boxH/2}" r="5" fill="none"/>
    </g>
  </svg>`;

  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svgString);
}

async function main() {
  console.log('[SEED] Starting InspectAI seed process...');

  // 1. Seed Users (Admin, Operator, Viewer)
  const adminPasswordHash = await bcrypt.hash('admin123', 10);
  const operatorPasswordHash = await bcrypt.hash('operator123', 10);
  const viewerPasswordHash = await bcrypt.hash('viewer123', 10);

  const adminUser = await prisma.user.upsert({
    where: { email: 'admin@inspectai.com' },
    update: {},
    create: {
      name: 'System Administrator',
      email: 'admin@inspectai.com',
      passwordHash: adminPasswordHash,
      role: 'ADMIN',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      settings: {
        create: {
          theme: 'dark',
          demoMode: true,
          notifications: true,
          confidenceThreshold: 70.0,
          autoSave: true,
          continuousInspection: false,
          backendUrl: 'http://192.168.1.100:8000/api',
        },
      },
    },
  });

  const operatorUser = await prisma.user.upsert({
    where: { email: 'operator@inspectai.com' },
    update: {},
    create: {
      name: 'Lead Operator Marcus',
      email: 'operator@inspectai.com',
      passwordHash: operatorPasswordHash,
      role: 'OPERATOR',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      settings: {
        create: {
          theme: 'dark',
          demoMode: true,
          notifications: true,
          confidenceThreshold: 70.0,
          autoSave: true,
          backendUrl: 'http://192.168.1.100:8000/api',
        },
      },
    },
  });

  const viewerUser = await prisma.user.upsert({
    where: { email: 'viewer@inspectai.com' },
    update: {},
    create: {
      name: 'QA Inspector Sarah',
      email: 'viewer@inspectai.com',
      passwordHash: viewerPasswordHash,
      role: 'VIEWER',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
      settings: {
        create: {
          theme: 'dark',
          demoMode: true,
          notifications: true,
          confidenceThreshold: 75.0,
          autoSave: true,
          backendUrl: 'http://192.168.1.100:8000/api',
        },
      },
    },
  });

  // 2. Seed Device
  const device = await prisma.device.upsert({
    where: { deviceId: 'INSPECT-UNIT-01' },
    update: {
      status: 'ONLINE',
      cameraStatus: 'ONLINE',
      aiStatus: 'READY',
      ledStatus: true,
      ledBrightness: 75,
      uptime: '14h 32m',
    },
    create: {
      deviceId: 'INSPECT-UNIT-01',
      name: 'Inspection Unit - 01',
      deviceType: 'ESP32 Inspection Controller',
      ipAddress: '192.168.1.100',
      signalStrength: 'Strong',
      status: 'ONLINE',
      cameraStatus: 'ONLINE',
      cameraResolution: '1920 x 1080',
      cameraFps: 24,
      aiStatus: 'READY',
      ledStatus: true,
      ledBrightness: 75,
      uptime: '14h 32m',
      lastInspection: new Date(),
    },
  });

  // 3. Seed Products
  const productsData = [
    {
      productId: 'PCB-001',
      name: 'Industrial Controller Motherboard V2',
      category: 'Electronics / Mainboard',
      status: 'ACTIVE',
      supportedDefects: 'Scratch, Crack, Missing Component, Wrong Component, Surface Defect, Damaged Component, Misalignment, Unknown Defect',
      specifications: JSON.stringify({ layers: 4, thickness: '1.6mm', tolerance: '±0.05mm', targetFov: '85mm x 55mm' }),
    },
    {
      productId: 'PCB-002',
      name: 'High-Voltage Power Regulator Board',
      category: 'Power Electronics',
      status: 'ACTIVE',
      supportedDefects: 'Scratch, Missing Component, Wrong Component, Misalignment',
      specifications: JSON.stringify({ layers: 2, thickness: '2.0mm', copperWeight: '2oz' }),
    },
    {
      productId: 'PCB-003',
      name: 'Optical Sensor Transceiver Module',
      category: 'Optoelectronics',
      status: 'ACTIVE',
      supportedDefects: 'Scratch, Crack, Surface Defect, Damaged Component',
      specifications: JSON.stringify({ layers: 6, thickness: '1.0mm', surfaceFinish: 'ENIG' }),
    },
    {
      productId: 'PCB-004',
      name: 'Wireless IoT Telemetry Node',
      category: 'RF / Communications',
      status: 'ACTIVE',
      supportedDefects: 'Missing Component, Wrong Component, Misalignment, Scratch',
      specifications: JSON.stringify({ layers: 4, thickness: '1.2mm', frequency: '2.4GHz / 868MHz' }),
    },
  ];

  for (const prod of productsData) {
    await prisma.product.upsert({
      where: { productId: prod.productId },
      update: prod,
      create: prod,
    });
  }

  // 4. Seed 24+ Realistic Inspection Records (Pass rate ~89%, Fail ~11%)
  await prisma.inspection.deleteMany({}); // fresh demo seed

  const rawInspections = [
    {
      inspectionId: 'INS-20261005-00124',
      productId: 'PCB-001',
      productName: 'Industrial Controller Motherboard V2',
      timestamp: new Date('2026-10-05T09:42:00'),
      result: 'FAIL',
      defect: 'Missing Component',
      confidence: 0.964,
      location: 'Top Right',
      severity: 'HIGH',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 182,
      notes: 'Capacitor C14 absent on high-speed data bus pad.',
      boxes: [{ x: 460, y: 60, w: 120, h: 90, label: 'Missing Component 96.4%', confidence: 0.964, color: '#ef4444' }],
    },
    {
      inspectionId: 'INS-20261005-00123',
      productId: 'PCB-001',
      productName: 'Industrial Controller Motherboard V2',
      timestamp: new Date('2026-10-05T09:38:15'),
      result: 'PASS',
      defect: 'None',
      confidence: 0.987,
      location: 'None',
      severity: 'NONE',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 165,
      notes: 'All SMD solder joints and passive placements verified nominal.',
      boxes: [{ x: 270, y: 145, w: 100, h: 90, label: 'Normal 98.7%', confidence: 0.987, color: '#22c55e' }],
    },
    {
      inspectionId: 'INS-20261005-00122',
      productId: 'PCB-002',
      productName: 'High-Voltage Power Regulator Board',
      timestamp: new Date('2026-10-05T09:31:40'),
      result: 'PASS',
      defect: 'None',
      confidence: 0.991,
      location: 'None',
      severity: 'NONE',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 172,
      notes: 'Power traces clearance 100% compliant.',
      boxes: [{ x: 260, y: 150, w: 160, h: 110, label: 'Normal 99.1%', confidence: 0.991, color: '#22c55e' }],
    },
    {
      inspectionId: 'INS-20261005-00121',
      productId: 'PCB-001',
      productName: 'Industrial Controller Motherboard V2',
      timestamp: new Date('2026-10-05T09:25:10'),
      result: 'FAIL',
      defect: 'Scratch',
      confidence: 0.942,
      location: 'Center',
      severity: 'MEDIUM',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 194,
      notes: 'Surface copper mask scratch across trace channel B4.',
      boxes: [{ x: 260, y: 150, w: 160, h: 110, label: 'Scratch 94.2%', confidence: 0.942, color: '#ef4444' }],
    },
    {
      inspectionId: 'INS-20261005-00120',
      productId: 'PCB-003',
      productName: 'Optical Sensor Transceiver Module',
      timestamp: new Date('2026-10-05T09:18:00'),
      result: 'PASS',
      defect: 'None',
      confidence: 0.978,
      location: 'None',
      severity: 'NONE',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 159,
      notes: 'Sensor alignment within 0.01mm tolerance.',
      boxes: [{ x: 270, y: 145, w: 100, h: 90, label: 'Normal 97.8%', confidence: 0.978, color: '#22c55e' }],
    },
    {
      inspectionId: 'INS-20261005-00119',
      productId: 'PCB-001',
      productName: 'Industrial Controller Motherboard V2',
      timestamp: new Date('2026-10-05T09:10:45'),
      result: 'PASS',
      defect: 'None',
      confidence: 0.982,
      location: 'None',
      severity: 'NONE',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 168,
      notes: 'Passed automated optical inspection.',
      boxes: [{ x: 270, y: 145, w: 100, h: 90, label: 'Normal 98.2%', confidence: 0.982, color: '#22c55e' }],
    },
    {
      inspectionId: 'INS-20261005-00118',
      productId: 'PCB-004',
      productName: 'Wireless IoT Telemetry Node',
      timestamp: new Date('2026-10-05T09:02:30'),
      result: 'FAIL',
      defect: 'Misalignment',
      confidence: 0.915,
      location: 'Bottom Left',
      severity: 'MEDIUM',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 201,
      notes: 'QFN chip rotated 14 degrees out of alignment.',
      boxes: [{ x: 70, y: 230, w: 120, h: 90, label: 'Misalignment 91.5%', confidence: 0.915, color: '#f59e0b' }],
    },
    {
      inspectionId: 'INS-20261005-00117',
      productId: 'PCB-001',
      productName: 'Industrial Controller Motherboard V2',
      timestamp: new Date('2026-10-05T08:55:12'),
      result: 'PASS',
      defect: 'None',
      confidence: 0.994,
      location: 'None',
      severity: 'NONE',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 161,
      notes: 'Optimal soldering profile detected.',
      boxes: [{ x: 270, y: 145, w: 100, h: 90, label: 'Normal 99.4%', confidence: 0.994, color: '#22c55e' }],
    },
    {
      inspectionId: 'INS-20261005-00116',
      productId: 'PCB-002',
      productName: 'High-Voltage Power Regulator Board',
      timestamp: new Date('2026-10-05T08:48:50'),
      result: 'PASS',
      defect: 'None',
      confidence: 0.976,
      location: 'None',
      severity: 'NONE',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 174,
      notes: 'High voltage clearances verified.',
      boxes: [{ x: 260, y: 150, w: 160, h: 110, label: 'Normal 97.6%', confidence: 0.976, color: '#22c55e' }],
    },
    {
      inspectionId: 'INS-20261005-00115',
      productId: 'PCB-001',
      productName: 'Industrial Controller Motherboard V2',
      timestamp: new Date('2026-10-05T08:41:20'),
      result: 'FAIL',
      defect: 'Crack',
      confidence: 0.958,
      location: 'Top Left',
      severity: 'CRITICAL',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 189,
      notes: 'Micro-fracture detected in FR4 substrate near mounting hole.',
      boxes: [{ x: 60, y: 60, w: 130, h: 95, label: 'Crack 95.8%', confidence: 0.958, color: '#ef4444' }],
    },
    {
      inspectionId: 'INS-20261005-00114',
      productId: 'PCB-001',
      productName: 'Industrial Controller Motherboard V2',
      timestamp: new Date('2026-10-05T08:35:10'),
      result: 'PASS',
      defect: 'None',
      confidence: 0.989,
      location: 'None',
      severity: 'NONE',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 167,
      notes: 'Zero defects observed.',
      boxes: [{ x: 270, y: 145, w: 100, h: 90, label: 'Normal 98.9%', confidence: 0.989, color: '#22c55e' }],
    },
    {
      inspectionId: 'INS-20261005-00113',
      productId: 'PCB-003',
      productName: 'Optical Sensor Transceiver Module',
      timestamp: new Date('2026-10-05T08:28:40'),
      result: 'PASS',
      defect: 'None',
      confidence: 0.985,
      location: 'None',
      severity: 'NONE',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 158,
      notes: 'Optical lens clean and seated.',
      boxes: [{ x: 270, y: 145, w: 100, h: 90, label: 'Normal 98.5%', confidence: 0.985, color: '#22c55e' }],
    },
    {
      inspectionId: 'INS-20261005-00112',
      productId: 'PCB-001',
      productName: 'Industrial Controller Motherboard V2',
      timestamp: new Date('2026-10-05T08:20:15'),
      result: 'PASS',
      defect: 'None',
      confidence: 0.992,
      location: 'None',
      severity: 'NONE',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 163,
      notes: 'SMD passives aligned correctly.',
      boxes: [{ x: 270, y: 145, w: 100, h: 90, label: 'Normal 99.2%', confidence: 0.992, color: '#22c55e' }],
    },
    {
      inspectionId: 'INS-20261005-00111',
      productId: 'PCB-004',
      productName: 'Wireless IoT Telemetry Node',
      timestamp: new Date('2026-10-05T08:12:05'),
      result: 'FAIL',
      defect: 'Wrong Component',
      confidence: 0.938,
      location: 'Bottom Right',
      severity: 'HIGH',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 184,
      notes: '10k Ohm resistor installed instead of 100k Ohm feedback resistor.',
      boxes: [{ x: 450, y: 240, w: 130, h: 90, label: 'Wrong Component 93.8%', confidence: 0.938, color: '#ef4444' }],
    },
    {
      inspectionId: 'INS-20261005-00110',
      productId: 'PCB-001',
      productName: 'Industrial Controller Motherboard V2',
      timestamp: new Date('2026-10-05T08:05:00'),
      result: 'PASS',
      defect: 'None',
      confidence: 0.984,
      location: 'None',
      severity: 'NONE',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 169,
      notes: 'All automated criteria met.',
      boxes: [{ x: 270, y: 145, w: 100, h: 90, label: 'Normal 98.4%', confidence: 0.984, color: '#22c55e' }],
    },
    {
      inspectionId: 'INS-20261005-00109',
      productId: 'PCB-002',
      productName: 'High-Voltage Power Regulator Board',
      timestamp: new Date('2026-10-05T07:58:20'),
      result: 'PASS',
      defect: 'None',
      confidence: 0.990,
      location: 'None',
      severity: 'NONE',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 171,
      notes: 'Trace thickness within specification.',
      boxes: [{ x: 260, y: 150, w: 160, h: 110, label: 'Normal 99.0%', confidence: 0.990, color: '#22c55e' }],
    },
    {
      inspectionId: 'INS-20261005-00108',
      productId: 'PCB-001',
      productName: 'Industrial Controller Motherboard V2',
      timestamp: new Date('2026-10-05T07:50:45'),
      result: 'PASS',
      defect: 'None',
      confidence: 0.981,
      location: 'None',
      severity: 'NONE',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 164,
      notes: 'Verified against golden master board.',
      boxes: [{ x: 270, y: 145, w: 100, h: 90, label: 'Normal 98.1%', confidence: 0.981, color: '#22c55e' }],
    },
    {
      inspectionId: 'INS-20261005-00107',
      productId: 'PCB-001',
      productName: 'Industrial Controller Motherboard V2',
      timestamp: new Date('2026-10-05T07:42:30'),
      result: 'FAIL',
      defect: 'Surface Defect',
      confidence: 0.887,
      location: 'Top Left',
      severity: 'LOW',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 179,
      notes: 'Flux residue puddle near microcontroller edge.',
      boxes: [{ x: 60, y: 60, w: 130, h: 95, label: 'Surface Defect 88.7%', confidence: 0.887, color: '#eab308' }],
    },
    {
      inspectionId: 'INS-20261005-00106',
      productId: 'PCB-003',
      productName: 'Optical Sensor Transceiver Module',
      timestamp: new Date('2026-10-05T07:35:10'),
      result: 'PASS',
      defect: 'None',
      confidence: 0.995,
      location: 'None',
      severity: 'NONE',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 156,
      notes: 'Sensor package pristine.',
      boxes: [{ x: 270, y: 145, w: 100, h: 90, label: 'Normal 99.5%', confidence: 0.995, color: '#22c55e' }],
    },
    {
      inspectionId: 'INS-20261005-00105',
      productId: 'PCB-001',
      productName: 'Industrial Controller Motherboard V2',
      timestamp: new Date('2026-10-05T07:28:00'),
      result: 'PASS',
      defect: 'None',
      confidence: 0.988,
      location: 'None',
      severity: 'NONE',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 166,
      notes: 'No abnormalities flagged.',
      boxes: [{ x: 270, y: 145, w: 100, h: 90, label: 'Normal 98.8%', confidence: 0.988, color: '#22c55e' }],
    },
    {
      inspectionId: 'INS-20261005-00104',
      productId: 'PCB-002',
      productName: 'High-Voltage Power Regulator Board',
      timestamp: new Date('2026-10-05T07:20:15'),
      result: 'PASS',
      defect: 'None',
      confidence: 0.979,
      location: 'None',
      severity: 'NONE',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 170,
      notes: 'Insulation margins confirmed.',
      boxes: [{ x: 260, y: 150, w: 160, h: 110, label: 'Normal 97.9%', confidence: 0.979, color: '#22c55e' }],
    },
    {
      inspectionId: 'INS-20261005-00103',
      productId: 'PCB-001',
      productName: 'Industrial Controller Motherboard V2',
      timestamp: new Date('2026-10-05T07:12:40'),
      result: 'PASS',
      defect: 'None',
      confidence: 0.993,
      location: 'None',
      severity: 'NONE',
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: 162,
      notes: 'All 48 pin pads fully soldered.',
      boxes: [{ x: 270, y: 145, w: 100, h: 90, label: 'Normal 99.3%', confidence: 0.993, color: '#22c55e' }],
    },
  ];

  for (const item of rawInspections) {
    const isPass = item.result === 'PASS';
    const label = isPass ? `Normal ${(item.confidence * 100).toFixed(1)}%` : `${item.defect} ${(item.confidence * 100).toFixed(1)}%`;
    const svgUrl = generatePcbSvg({
      defectType: item.defect,
      location: item.location,
      label,
      isPass,
    });

    await prisma.inspection.create({
      data: {
        inspectionId: item.inspectionId,
        productId: item.productId,
        productName: item.productName,
        timestamp: item.timestamp,
        result: item.result,
        defect: item.defect,
        confidence: item.confidence,
        location: item.location,
        severity: item.severity,
        model: item.model,
        processingTimeMs: item.processingTimeMs,
        imageUrl: svgUrl,
        rawImageUrl: svgUrl,
        boundingBoxesJson: JSON.stringify(item.boxes),
        notes: item.notes,
        saved: true,
      },
    });
  }

  // 5. Seed Alerts
  await prisma.alert.deleteMany({});
  await prisma.alert.createMany({
    data: [
      {
        title: 'High Defect Severity Flagged',
        message: 'PCB-001 (INS-20261005-00124) failed with Missing Component (96.4% confidence).',
        type: 'ERROR',
        source: 'AI Model',
        timestamp: new Date('2026-10-05T09:42:05'),
        read: false,
      },
      {
        title: 'Inspection Completed Successfully',
        message: 'Batch inspection sequence PCB-001 to PCB-004 finished with 89.1% Pass Rate.',
        type: 'SUCCESS',
        source: 'Inspection',
        timestamp: new Date('2026-10-05T09:30:00'),
        read: true,
      },
      {
        title: 'ESP32 Control Unit Connected',
        message: 'Hardware handshake verified at 192.168.1.100 (Signal: -42dBm Strong).',
        type: 'INFO',
        source: 'ESP32',
        timestamp: new Date('2026-10-05T07:00:00'),
        read: true,
      },
      {
        title: 'Ring LED Calibration Active',
        message: 'Ring LED brightness stabilized at 75% for optimal polarization & shadow removal.',
        type: 'INFO',
        source: 'System',
        timestamp: new Date('2026-10-05T07:05:00'),
        read: true,
      },
    ],
  });

  console.log('[SEED] InspectAI seed complete!');
  console.log('----------------------------------------------------');
  console.log('Demo Login credentials:');
  console.log('Admin:    admin@inspectai.com    / admin123');
  console.log('Operator: operator@inspectai.com / operator123');
  console.log('Viewer:   viewer@inspectai.com   / viewer123');
  console.log('----------------------------------------------------');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
