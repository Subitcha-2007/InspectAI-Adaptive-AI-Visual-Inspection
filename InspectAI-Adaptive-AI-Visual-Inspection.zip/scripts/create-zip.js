const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const rootDir = process.cwd();
const staging = path.join(process.env.TEMP, 'legacy_export_stage');

if (fs.existsSync(staging)) {
  fs.rmSync(staging, { recursive: true, force: true });
}
fs.mkdirSync(staging, { recursive: true });

const toCopy = [
  'src', 'public', 'scripts', '.env.example', '.gitignore',
  'Dockerfile', 'package.json', 'package-lock.json', 'postcss.config.js',
  'README.md', 'render.yaml', 'tailwind.config.js', 'tsconfig.json', 'vercel.json'
];

toCopy.forEach(item => {
  const srcPath = path.join(rootDir, item);
  if (fs.existsSync(srcPath)) {
    fs.cpSync(srcPath, path.join(staging, item), { recursive: true });
  }
});

const prismaStaging = path.join(staging, 'prisma');
fs.mkdirSync(prismaStaging, { recursive: true });
if (fs.existsSync(path.join(rootDir, 'prisma', 'schema.prisma'))) {
  fs.copyFileSync(path.join(rootDir, 'prisma', 'schema.prisma'), path.join(prismaStaging, 'schema.prisma'));
}

const zipTarget = path.join(rootDir, 'legacy-to-modern-translator.zip');
if (fs.existsSync(zipTarget)) {
  fs.unlinkSync(zipTarget);
}

const psCmd = `powershell -NoProfile -Command "Compress-Archive -Path '${staging}\\*' -DestinationPath '${zipTarget}' -Force"`;
execSync(psCmd, { stdio: 'inherit' });

fs.rmSync(staging, { recursive: true, force: true });

if (fs.existsSync(zipTarget)) {
  const stats = fs.statSync(zipTarget);
  console.log('ZIP_SUCCESS:', zipTarget, stats.size, 'bytes');
} else {
  console.error('ZIP_FAILED');
  process.exit(1);
}
