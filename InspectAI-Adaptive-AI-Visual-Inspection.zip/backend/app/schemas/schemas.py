from typing import List, Optional, Any
from datetime import datetime
from pydantic import BaseModel, Field

# Base API Response
class ApiResponse(BaseModel):
    success: bool
    message: str = "Operation successful"
    data: Optional[Any] = None
    error_code: Optional[str] = None

# Auth Schemas
class LoginRequest(BaseModel):
    email: str
    password: str

class RegisterRequest(BaseModel):
    name: str
    email: str
    password: str
    role: Optional[str] = "OPERATOR"

class UserResponse(BaseModel):
    id: str
    name: str
    email: str
    role: str
    avatar: Optional[str] = None

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse

# Bounding Box & Defect Schemas
class BoundingBox(BaseModel):
    x: int
    y: int
    width: int
    height: int

class DefectItem(BaseModel):
    defect_type: str
    confidence: float
    bounding_box: BoundingBox
    location: str
    severity: str

# Inspection Schemas
class InspectionStartRequest(BaseModel):
    device_id: Optional[str] = "INSPECT-UNIT-01"
    product_id: Optional[str] = "PCB-001"
    operator_name: Optional[str] = "Lead Operator Marcus"

class InspectionResponse(BaseModel):
    id: str
    inspection_id: str
    product_id: Optional[str]
    product_name: str
    timestamp: datetime
    result: str # PASS, FAIL, REVIEW
    defect: str
    confidence: float
    location: str
    severity: str
    model: str
    processing_time_ms: int
    image_url: str
    notes: Optional[str] = None
    defects: List[DefectItem] = []

# Device & LED Schemas
class LedControlRequest(BaseModel):
    state: bool
    brightness: int = Field(75, ge=0, le=100)

class DeviceStatusResponse(BaseModel):
    id: str
    device_id: str
    name: str
    device_type: str
    ip_address: str
    signal_strength: str
    status: str
    camera_status: str
    camera_resolution: str
    camera_fps: int
    ai_status: str
    led_status: bool
    led_brightness: int
    uptime: str
    last_inspection: Optional[datetime] = None

# Product Schemas
class ProductCreateRequest(BaseModel):
    product_id: str
    name: str
    category: Optional[str] = "Electronics / PCB"
    status: Optional[str] = "ACTIVE"
    supported_defects: Optional[str] = "Scratch, Crack, Missing Component, Wrong Component, Surface Defect, Misalignment"
    specifications: Optional[str] = None

# Synthetic Dataset Schemas
class DatasetGenerateRequest(BaseModel):
    dataset_name: str = "Industrial-PCB-Synthetic-V1"
    num_samples: int = 50
    defect_types: List[str] = ["Scratch", "Crack", "Missing Component", "Wrong Component", "Surface Defect"]

class DatasetStatsResponse(BaseModel):
    total_images: int
    normal_images: int
    synthetic_images: int
    annotated_images: int
    train_count: int
    val_count: int
    test_count: int
    classes: List[str]

# Settings Schemas
class SettingsUpdateRequest(BaseModel):
    theme: Optional[str] = "light"
    demo_mode: Optional[bool] = True
    notifications: Optional[bool] = True
    confidence_threshold: Optional[float] = 70.0
    auto_save: Optional[bool] = True
    continuous_inspection: Optional[bool] = False
    backend_url: Optional[str] = "http://192.168.1.100:8000/api"
    esp32_ip: Optional[str] = "192.168.1.100"
