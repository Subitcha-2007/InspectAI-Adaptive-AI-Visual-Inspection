import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    PROJECT_NAME: str = "InspectAI - Low-Cost Adaptive AI Visual Inspection System"
    API_V1_STR: str = "/api"
    SECRET_KEY: str = os.getenv("JWT_SECRET", "inspectai-super-secret-jwt-key-for-industrial-edge-2026")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7 # 7 days
    
    # Database: Supports PostgreSQL, fallbacks cleanly to SQLite for local development
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./inspectai.db")
    
    # Edge AI & Computer Vision Settings
    AI_MODEL_PATH: str = os.getenv("AI_MODEL_PATH", "ai/models/yolov8_defect_detector.pt")
    CONFIDENCE_THRESHOLD: float = float(os.getenv("CONFIDENCE_THRESHOLD", "0.70"))
    IOU_THRESHOLD: float = float(os.getenv("IOU_THRESHOLD", "0.45"))
    
    # Hardware & Peripherals
    ESP32_IP: str = os.getenv("ESP32_IP", "192.168.1.100")
    CAMERA_URL: str = os.getenv("CAMERA_URL", "0") # USB camera index 0 or RTSP stream URL
    DEMO_MODE: bool = os.getenv("DEMO_MODE", "true").lower() == "true"
    
    # Storage
    DATASET_DIR: str = "ai/datasets"
    SYNTHETIC_OUTPUT_DIR: str = "ai/synthetic_data"

    class Config:
        case_sensitive = True

settings = Settings()
