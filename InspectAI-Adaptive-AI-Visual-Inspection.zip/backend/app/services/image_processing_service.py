import cv2
import numpy as np
import random
from typing import Tuple, Dict, Any, List

class ImageProcessingService:
    """
    OpenCV Computer Vision Pipeline:
    Image Acquisition -> Noise Reduction -> Brightness Normalization -> CLAHE Enhancement
    """

    @staticmethod
    def preprocess_image(image_bgr: np.ndarray) -> np.ndarray:
        """
        Applies standard industrial optical preprocessing:
        1. Bilateral filtering for edge-preserving noise reduction
        2. Contrast Limited Adaptive Histogram Equalization (CLAHE) for illumination balancing
        """
        # Noise reduction while preserving trace & defect edges
        denoised = cv2.bilateralFilter(image_bgr, d=7, sigmaColor=50, sigmaSpace=50)
        
        # Convert to LAB color space for luminance normalization
        lab = cv2.cvtColor(denoised, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        
        # Apply CLAHE to L-channel to eliminate ring LED glare & shadows
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        cl = clahe.apply(l)
        
        # Merge back and convert to BGR
        limg = cv2.merge((cl, a, b))
        enhanced = cv2.cvtColor(limg, cv2.COLOR_LAB2BGR)
        return enhanced

    @staticmethod
    def create_synthetic_defect(
        base_img: np.ndarray, defect_type: str
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        """
        Synthetic Defect Generation Engine:
        Injects mathematically realistic manufacturing flaws into golden master product images.
        """
        img = base_img.copy()
        h, w, _ = img.shape
        
        # Random location quadrant
        x = random.randint(int(w * 0.15), int(w * 0.70))
        y = random.randint(int(h * 0.15), int(h * 0.70))
        bw = random.randint(80, 140)
        bh = random.randint(60, 110)
        
        location = "Center"
        if x < w / 3 and y < h / 3:
            location = "Top Left"
        elif x > (2 * w) / 3 and y < h / 3:
            location = "Top Right"
        elif x < w / 3 and y > (2 * h) / 3:
            location = "Bottom Left"
        elif x > (2 * w) / 3 and y > (2 * h) / 3:
            location = "Bottom Right"

        severity = "MEDIUM"

        if defect_type == "Scratch":
            # Curved realistic scratch trajectory
            pts = np.array([
                [x + 10, y + bh - 15],
                [x + bw // 2, y + bh // 3],
                [x + bw - 10, y + 15]
            ], np.int32)
            cv2.polylines(img, [pts], isClosed=False, color=(251, 191, 36), thickness=3, lineType=cv2.LINE_AA)
            cv2.polylines(img, [pts + 1], isClosed=False, color=(248, 113, 113), thickness=1, lineType=cv2.LINE_AA)
            severity = "MEDIUM"
            
        elif defect_type == "Crack":
            # Jagged fracture lines
            pts = np.array([
                [x + 15, y + 10],
                [x + bw // 3, y + bh // 2],
                [x + (2 * bw) // 3, y + bh // 3],
                [x + bw - 15, y + bh - 10]
            ], np.int32)
            cv2.polylines(img, [pts], isClosed=False, color=(239, 68, 68), thickness=3, lineType=cv2.LINE_AA)
            severity = "CRITICAL"

        elif defect_type == "Missing Component":
            # Blank solder pads with solder residue
            cv2.rectangle(img, (x + 20, y + 15), (x + bw - 20, y + bh - 15), (30, 41, 59), -1)
            cv2.rectangle(img, (x + 20, y + 15), (x + bw - 20, y + bh - 15), (244, 63, 94), 2)
            # Empty solder dots
            for cx in [x + 25, x + bw - 25]:
                for cy in [y + 20, y + bh - 20]:
                    cv2.circle(img, (cx, cy), 3, (203, 213, 225), -1)
            severity = "HIGH"

        elif defect_type == "Wrong Component":
            # Mismatched color component loaded
            cv2.rectangle(img, (x + 20, y + 15), (x + bw - 20, y + bh - 15), (147, 51, 234), -1)
            cv2.putText(img, "47k", (x + 30, y + bh // 2 + 5), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
            severity = "HIGH"

        elif defect_type == "Misalignment":
            # Skewed component
            rect = ((x + bw // 2, y + bh // 2), (bw - 40, bh - 30), 16.0)
            box = cv2.boxPoints(rect)
            box = np.int0(box)
            cv2.drawContours(img, [box], 0, (245, 158, 11), -1)
            severity = "MEDIUM"
            
        else: # Surface Defect
            cv2.ellipse(img, (x + bw // 2, y + bh // 2), (bw // 3, bh // 4), 30, 0, 360, (234, 179, 8), -1)
            severity = "LOW"

        confidence = round(random.uniform(0.91, 0.985), 3)

        defect_info = {
            "defect_type": defect_type,
            "confidence": confidence,
            "bounding_box": {
                "x": x,
                "y": y,
                "width": bw,
                "height": bh,
            },
            "location": location,
            "severity": severity,
        }

        return img, defect_info

image_processing_service = ImageProcessingService()
