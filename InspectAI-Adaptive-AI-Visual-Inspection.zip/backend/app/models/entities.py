import uuid
from datetime import datetime
from sqlalchemy import (
    Column,
    String,
    Integer,
    Float,
    Boolean,
    DateTime,
    ForeignKey,
    Text,
)
from sqlalchemy.orm import relationship
from backend.app.database.session import Base

def generate_uuid():
    return str(uuid.uuid4())

class User(Base):
    __tablename__ = "users"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(String, default="OPERATOR") # ADMIN, OPERATOR, VIEWER
    avatar = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Device(Base):
    __tablename__ = "devices"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    device_id = Column(String, unique=True, index=True, default="INSPECT-UNIT-01")
    name = Column(String, default="Inspection Unit - 01")
    device_type = Column(String, default="ESP32 Inspection Controller")
    ip_address = Column(String, default="192.168.1.100")
    signal_strength = Column(String, default="Strong")
    status = Column(String, default="ONLINE") # ONLINE, OFFLINE, MAINTENANCE
    camera_status = Column(String, default="ONLINE")
    camera_resolution = Column(String, default="1920 x 1080")
    camera_fps = Column(Integer, default=24)
    ai_status = Column(String, default="READY")
    led_status = Column(Boolean, default=True)
    led_brightness = Column(Integer, default=75) # 0 - 100
    uptime = Column(String, default="14h 32m")
    last_inspection = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Product(Base):
    __tablename__ = "products"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    product_id = Column(String, unique=True, index=True, nullable=False) # e.g., PCB-001
    name = Column(String, nullable=False)
    category = Column(String, default="Electronics / PCB")
    status = Column(String, default="ACTIVE") # ACTIVE, INACTIVE
    supported_defects = Column(Text, default="Scratch, Crack, Missing Component, Wrong Component, Surface Defect, Misalignment")
    specifications = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    inspections = relationship("Inspection", back_populates="product")

class DefectConfig(Base):
    __tablename__ = "defects"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    name = Column(String, unique=True, nullable=False) # Scratch, Crack, etc.
    description = Column(String, nullable=True)
    severity = Column(String, default="MEDIUM") # LOW, MEDIUM, HIGH, CRITICAL
    confidence_threshold = Column(Float, default=0.70)
    color = Column(String, default="#DC2626")
    enabled = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class Inspection(Base):
    __tablename__ = "inspections"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    inspection_id = Column(String, unique=True, index=True, nullable=False) # INS-20261005-00124
    product_id = Column(String, ForeignKey("products.product_id"), nullable=True)
    product_name = Column(String, default="PCB Board")
    operator_id = Column(String, nullable=True)
    operator_name = Column(String, default="Lead Operator Marcus")
    device_id = Column(String, default="INSPECT-UNIT-01")
    timestamp = Column(DateTime, default=datetime.utcnow)
    result = Column(String, default="PASS") # PASS, FAIL, REVIEW
    defect_type = Column(String, default="None")
    confidence = Column(Float, default=0.95)
    location = Column(String, default="None")
    severity = Column(String, default="NONE")
    model_version = Column(String, default="YOLO Defect Detector v8.4")
    processing_time_ms = Column(Integer, default=182)
    image_url = Column(Text, nullable=False)
    raw_image_url = Column(Text, nullable=True)
    notes = Column(Text, nullable=True)
    manual_review = Column(Boolean, default=False)
    manual_verdict = Column(String, nullable=True)
    saved = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    product = relationship("Product", back_populates="inspections")
    defect_details = relationship("InspectionDefect", back_populates="inspection", cascade="all, delete-orphan")

class InspectionDefect(Base):
    __tablename__ = "inspection_defects"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    inspection_id = Column(String, ForeignKey("inspections.inspection_id"), nullable=False)
    defect_type = Column(String, nullable=False)
    confidence = Column(Float, nullable=False)
    bbox_x = Column(Integer, default=0)
    bbox_y = Column(Integer, default=0)
    bbox_width = Column(Integer, default=0)
    bbox_height = Column(Integer, default=0)
    location = Column(String, default="Center")
    severity = Column(String, default="MEDIUM")
    
    inspection = relationship("Inspection", back_populates="defect_details")

class Alert(Base):
    __tablename__ = "alerts"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    title = Column(String, nullable=False)
    message = Column(String, nullable=False)
    type = Column(String, default="INFO") # SUCCESS, WARNING, ERROR, INFO
    source = Column(String, default="System") # AI Model, Camera, ESP32, Inspection
    timestamp = Column(DateTime, default=datetime.utcnow)
    read = Column(Boolean, default=False)

class SyntheticDataset(Base):
    __tablename__ = "datasets"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    name = Column(String, nullable=False)
    description = Column(String, nullable=True)
    total_images = Column(Integer, default=0)
    normal_images = Column(Integer, default=0)
    synthetic_images = Column(Integer, default=0)
    annotated_images = Column(Integer, default=0)
    train_count = Column(Integer, default=0)
    val_count = Column(Integer, default=0)
    test_count = Column(Integer, default=0)
    classes_json = Column(Text, default='["Scratch","Crack","Missing Component","Wrong Component","Surface Defect","Misalignment"]')
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class SystemSettings(Base):
    __tablename__ = "system_settings"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    user_id = Column(String, unique=True, nullable=True)
    theme = Column(String, default="light")
    demo_mode = Column(Boolean, default=True)
    notifications = Column(Boolean, default=True)
    confidence_threshold = Column(Float, default=70.0)
    iou_threshold = Column(Float, default=45.0)
    auto_save = Column(Boolean, default=True)
    continuous_inspection = Column(Boolean, default=False)
    backend_url = Column(String, default="http://192.168.1.100:8000/api")
    esp32_ip = Column(String, default="192.168.1.100")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
