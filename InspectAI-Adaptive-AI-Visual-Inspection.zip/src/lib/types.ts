// InspectAI Client & API Types

export type UserRole = 'ADMIN' | 'OPERATOR' | 'VIEWER';

export type DefectType =
  | 'Scratch'
  | 'Crack'
  | 'Missing Component'
  | 'Wrong Component'
  | 'Surface Defect'
  | 'Damaged Component'
  | 'Misalignment'
  | 'Unknown Defect'
  | 'None';

export type DefectSeverity = 'NONE' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface BoundingBox {
  x: number;
  y: number;
  w: number;
  h: number;
  label: string;
  confidence: number;
  color: string;
}

export interface InspectionRecord {
  id: string;
  inspectionId: string;
  productId: string;
  productName: string;
  timestamp: string;
  result: 'PASS' | 'FAIL';
  defect: DefectType;
  confidence: number;
  location: string;
  severity: DefectSeverity;
  model: string;
  processingTimeMs: number;
  imageUrl: string;
  rawImageUrl?: string;
  boundingBoxesJson?: string;
  boundingBoxes?: BoundingBox[];
  notes?: string;
  saved: boolean;
}

export interface DeviceStatus {
  id: string;
  deviceId: string;
  name: string;
  deviceType: string;
  ipAddress: string;
  signalStrength: 'Strong' | 'Good' | 'Weak' | 'Disconnected';
  status: 'ONLINE' | 'OFFLINE' | 'MAINTENANCE';
  cameraStatus: 'ONLINE' | 'OFFLINE';
  cameraResolution: string;
  cameraFps: number;
  aiStatus: 'READY' | 'PROCESSING' | 'ERROR';
  ledStatus: boolean;
  ledBrightness: number; // 0 - 100
  uptime: string;
  lastInspection?: string;
}

export interface AnalyticsData {
  totalInspections: number;
  passCount: number;
  failCount: number;
  passRate: number;
  failRate: number;
  avgConfidence: number;
  avgProcessingTimeMs: number;
  defectDistribution: { type: string; count: number; percentage: number; color: string }[];
  dailyTrends: { date: string; total: number; pass: number; fail: number }[];
  severityBreakdown: { severity: string; count: number }[];
}

export interface ProductItem {
  id: string;
  productId: string;
  name: string;
  category: string;
  status: 'ACTIVE' | 'INACTIVE';
  supportedDefects: string;
  specifications?: string;
  inspectionCount?: number;
}

export interface AlertItem {
  id: string;
  title: string;
  message: string;
  type: 'SUCCESS' | 'WARNING' | 'ERROR' | 'INFO';
  source: string;
  timestamp: string;
  read: boolean;
}

export interface AppSettings {
  theme: 'dark' | 'light';
  demoMode: boolean;
  notifications: boolean;
  confidenceThreshold: number;
  autoSave: boolean;
  continuousInspection: boolean;
  backendUrl: string;
  deviceId: string;
}
