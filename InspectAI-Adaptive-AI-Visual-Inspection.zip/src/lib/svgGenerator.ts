export function generatePcbSvg({
  defectType = 'None',
  location = 'None',
  label = 'Normal',
  isPass = true,
}: {
  defectType?: string;
  location?: string;
  label?: string;
  isPass?: boolean;
}): string {
  const boxColor = isPass ? '#22c55e' : '#ef4444';
  const boxBg = isPass ? 'rgba(34, 197, 94, 0.15)' : 'rgba(239, 68, 68, 0.18)';

  let boxX = 260, boxY = 145, boxW = 140, boxH = 100;
  if (location === 'Top Right') { boxX = 460; boxY = 60; boxW = 120; boxH = 90; }
  else if (location === 'Top Left') { boxX = 60; boxY = 60; boxW = 130; boxH = 95; }
  else if (location === 'Center') { boxX = 260; boxY = 145; boxW = 150; boxH = 105; }
  else if (location === 'Bottom Right') { boxX = 450; boxY = 240; boxW = 130; boxH = 90; }
  else if (location === 'Bottom Left') { boxX = 70; boxY = 230; boxW = 120; boxH = 90; }

  const defectVisual = !isPass
    ? `
    ${
      defectType === 'Missing Component'
        ? `
      <rect x="${boxX + 25}" y="${boxY + 20}" width="50" height="40" fill="#1e293b" stroke="#f43f5e" stroke-width="2" stroke-dasharray="4,4"/>
      <line x1="${boxX + 20}" y1="${boxY + 15}" x2="${boxX + 80}" y2="${boxY + 65}" stroke="#ef4444" stroke-width="2.5"/>
      <line x1="${boxX + 80}" y1="${boxY + 15}" x2="${boxX + 20}" y2="${boxY + 65}" stroke="#ef4444" stroke-width="2.5"/>
      <circle cx="${boxX + 25}" cy="${boxY + 20}" r="3.5" fill="#cbd5e1"/>
      <circle cx="${boxX + 75}" cy="${boxY + 20}" r="3.5" fill="#cbd5e1"/>
      <circle cx="${boxX + 25}" cy="${boxY + 60}" r="3.5" fill="#cbd5e1"/>
      <circle cx="${boxX + 75}" cy="${boxY + 60}" r="3.5" fill="#cbd5e1"/>
    `
        : defectType === 'Scratch'
        ? `
      <path d="M ${boxX + 15} ${boxY + 70} Q ${boxX + 60} ${boxY + 30} ${boxX + 105} ${boxY + 20}" stroke="#fbbf24" stroke-width="3" fill="none" stroke-linecap="round"/>
      <path d="M ${boxX + 25} ${boxY + 75} Q ${boxX + 65} ${boxY + 40} ${boxX + 100} ${boxY + 25}" stroke="#f87171" stroke-width="2" fill="none"/>
    `
        : defectType === 'Crack'
        ? `
      <path d="M ${boxX + 30} ${boxY + 15} L ${boxX + 50} ${boxY + 45} L ${boxX + 45} ${boxY + 60} L ${boxX + 75} ${boxY + 80}" stroke="#ef4444" stroke-width="3.5" fill="none"/>
    `
        : defectType === 'Misalignment'
        ? `
      <rect x="${boxX + 30}" y="${boxY + 20}" width="50" height="40" rx="3" fill="#334155" stroke="#f59e0b" stroke-width="2" transform="rotate(14 ${boxX + 55} ${boxY + 40})"/>
    `
        : `
      <ellipse cx="${boxX + 55}" cy="${boxY + 45}" rx="30" ry="20" fill="rgba(244,63,94,0.3)" stroke="#ef4444" stroke-width="2"/>
    `
    }
  `
    : '';

  const svgString = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 360" width="640" height="360">
    <defs>
      <linearGradient id="pcbBg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#064e3b" />
        <stop offset="100%" stop-color="#022c22" />
      </linearGradient>
      <linearGradient id="chipGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#1e293b" />
        <stop offset="100%" stop-color="#0f172a" />
      </linearGradient>
      <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
        <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(16,185,129,0.08)" stroke-width="1"/>
      </pattern>
    </defs>
    
    <!-- PCB Board Base -->
    <rect width="640" height="360" fill="#0b1320"/>
    <rect x="20" y="20" width="600" height="320" rx="12" fill="url(#pcbBg)" stroke="#059669" stroke-width="3"/>
    <rect x="20" y="20" width="600" height="320" rx="12" fill="url(#grid)"/>

    <!-- Mounting Holes -->
    <circle cx="45" cy="45" r="8" fill="#0f172a" stroke="#d97706" stroke-width="3"/>
    <circle cx="595" cy="45" r="8" fill="#0f172a" stroke="#d97706" stroke-width="3"/>
    <circle cx="45" cy="315" r="8" fill="#0f172a" stroke="#d97706" stroke-width="3"/>
    <circle cx="595" cy="315" r="8" fill="#0f172a" stroke="#d97706" stroke-width="3"/>

    <!-- Copper Circuit Tracks -->
    <g stroke="#10b981" stroke-width="2" fill="none" opacity="0.75">
      <path d="M 60 120 L 140 120 L 170 150 L 260 150"/>
      <path d="M 60 140 L 130 140 L 160 170 L 260 170"/>
      <path d="M 60 160 L 120 160 L 150 190 L 260 190"/>
      <path d="M 420 160 L 480 160 L 520 120 L 570 120"/>
      <path d="M 420 180 L 490 180 L 530 220 L 570 220"/>
      <path d="M 320 80 L 320 140"/>
      <path d="M 340 80 L 340 140"/>
      <path d="M 360 80 L 360 140"/>
      <path d="M 320 260 L 320 300"/>
      <path d="M 360 260 L 360 300"/>
    </g>

    <!-- Soldering Pads & Vias -->
    <g fill="#d97706" stroke="#b45309" stroke-width="1">
      <circle cx="140" cy="80" r="3"/>
      <circle cx="155" cy="80" r="3"/>
      <circle cx="170" cy="80" r="3"/>
      <circle cx="185" cy="80" r="3"/>
      <circle cx="480" cy="80" r="3"/>
      <circle cx="495" cy="80" r="3"/>
      <circle cx="510" cy="80" r="3"/>
      <circle cx="480" cy="270" r="3"/>
      <circle cx="495" cy="270" r="3"/>
      <circle cx="510" cy="270" r="3"/>
    </g>

    <!-- Major IC Main Controller Chip -->
    <rect x="270" y="145" width="100" height="90" rx="4" fill="url(#chipGrad)" stroke="#334155" stroke-width="2"/>
    <circle cx="282" cy="157" r="3" fill="#64748b"/>
    <text x="320" y="188" fill="#94a3b8" font-family="monospace" font-size="10" font-weight="bold" text-anchor="middle">INSPECT-AI</text>
    <text x="320" y="202" fill="#64748b" font-family="monospace" font-size="8" text-anchor="middle">STM32-ARM64</text>
    
    <!-- IC Pins -->
    <g fill="#94a3b8">
      <rect x="280" y="137" width="4" height="8"/>
      <rect x="295" y="137" width="4" height="8"/>
      <rect x="310" y="137" width="4" height="8"/>
      <rect x="325" y="137" width="4" height="8"/>
      <rect x="340" y="137" width="4" height="8"/>
      <rect x="355" y="137" width="4" height="8"/>
      <rect x="280" y="235" width="4" height="8"/>
      <rect x="295" y="235" width="4" height="8"/>
      <rect x="310" y="235" width="4" height="8"/>
      <rect x="325" y="235" width="4" height="8"/>
      <rect x="340" y="235" width="4" height="8"/>
      <rect x="355" y="235" width="4" height="8"/>
    </g>

    <!-- Discrete SMD Components -->
    <rect x="180" y="90" width="16" height="28" rx="2" fill="#b45309" stroke="#78350f" stroke-width="1"/>
    <rect x="210" y="90" width="16" height="28" rx="2" fill="#b45309" stroke="#78350f" stroke-width="1"/>
    <rect x="440" y="240" width="28" height="14" rx="2" fill="#0284c7" stroke="#0369a1" stroke-width="1"/>
    <rect x="120" y="240" width="28" height="14" rx="2" fill="#334155" stroke="#1e293b" stroke-width="1"/>
    <rect x="160" y="240" width="28" height="14" rx="2" fill="#334155" stroke="#1e293b" stroke-width="1"/>

    <!-- Silkscreen Text Labels -->
    <text x="70" y="55" fill="#f8fafc" font-family="monospace" font-size="11" font-weight="bold">INSPECT-UNIT-01</text>
    <text x="70" y="70" fill="#a7f3d0" font-family="sans-serif" font-size="8">REV 4.2 / INDUSTRIAL IoT</text>
    <text x="500" y="325" fill="#6ee7b7" font-family="monospace" font-size="9">PASS QC-A4</text>

    ${defectVisual}

    <!-- AI Bounding Box Overlay -->
    <rect x="${boxX}" y="${boxY}" width="${boxW}" height="${boxH}" fill="${boxBg}" stroke="${boxColor}" stroke-width="2.5" stroke-dasharray="${isPass ? 'none' : '6,3'}" rx="4"/>
    
    <!-- AI Tag Pill -->
    <rect x="${boxX}" y="${boxY - 22}" width="${Math.max(label.length * 8 + 20, 95)}" height="22" rx="3" fill="${boxColor}"/>
    <text x="${boxX + 8}" y="${boxY - 7}" fill="#ffffff" font-family="sans-serif" font-size="11" font-weight="bold">${label}</text>

    <!-- Crosshair Target -->
    <g stroke="${boxColor}" stroke-width="1" opacity="0.8">
      <line x1="${boxX + boxW / 2 - 10}" y1="${boxY + boxH / 2}" x2="${boxX + boxW / 2 + 10}" y2="${boxY + boxH / 2}"/>
      <line x1="${boxX + boxW / 2}" y1="${boxY + boxH / 2 - 10}" x2="${boxX + boxW / 2}" y2="${boxY + boxH / 2 + 10}"/>
      <circle cx="${boxX + boxW / 2}" cy="${boxY + boxH / 2}" r="5" fill="none"/>
    </g>
  </svg>`;

  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svgString);
}
