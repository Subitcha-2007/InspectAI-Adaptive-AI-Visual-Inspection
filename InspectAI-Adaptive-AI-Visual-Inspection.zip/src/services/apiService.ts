import {
  InspectionRecord,
  DeviceStatus,
  AnalyticsData,
  ProductItem,
  AlertItem,
  AppSettings,
  UserRole,
} from '@/lib/types';
import { generatePcbSvg } from '@/lib/svgGenerator';

// Configurable Base URL (defaults to environment or standard local edge host)
export const DEFAULT_BASE_URL = process.env.NEXT_PUBLIC_API_URL || '';

class ApiService {
  private baseUrl: string = DEFAULT_BASE_URL;
  private isDemoMode: boolean = false;

  constructor() {
    if (typeof window !== 'undefined') {
      const savedUrl = localStorage.getItem('inspectai_backend_url');
      if (savedUrl) this.baseUrl = savedUrl;
      const savedDemo = localStorage.getItem('inspectai_demo_mode');
      if (savedDemo !== null) this.isDemoMode = savedDemo === 'true';
    }
  }

  public setBaseUrl(url: string) {
    this.baseUrl = url.trim().replace(/\/+$/, '');
    if (typeof window !== 'undefined') {
      localStorage.setItem('inspectai_backend_url', this.baseUrl);
    }
  }

  public getBaseUrl(): string {
    return this.baseUrl || '/api';
  }

  public setDemoMode(active: boolean) {
    this.isDemoMode = active;
    if (typeof window !== 'undefined') {
      localStorage.setItem('inspectai_demo_mode', String(active));
    }
  }

  public getDemoMode(): boolean {
    return this.isDemoMode;
  }

  private async fetchWithAuth(endpoint: string, options: RequestInit = {}) {
    const url = endpoint.startsWith('http') ? endpoint : `${this.baseUrl}${endpoint.startsWith('/') ? '' : '/'}${endpoint}`;
    
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...((options.headers as Record<string, string>) || {}),
    };

    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('inspectai_token');
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
    }

    try {
      const res = await fetch(url, { ...options, headers });
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || `HTTP error! status: ${res.status}`);
      }
      return await res.json();
    } catch (error: any) {
      console.warn(`[InspectAI API] Request to ${url} failed, falling back to local handler if possible. Error:`, error.message);
      throw error;
    }
  }

  // --- Auth Service ---
  async login(email: string, password: string): Promise<{ success: boolean; user?: any; token?: string; error?: string }> {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Authentication failed');
      
      if (data.token && typeof window !== 'undefined') {
        localStorage.setItem('inspectai_token', data.token);
      }
      return data;
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  async logout(): Promise<void> {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // ignore
    }
    if (typeof window !== 'undefined') {
      localStorage.removeItem('inspectai_token');
    }
  }

  // --- Device & Hardware Service ---
  async getDeviceStatus(): Promise<DeviceStatus> {
    try {
      const res = await fetch('/api/device/status');
      if (res.ok) {
        const data = await res.json();
        return data.device;
      }
    } catch {
      // demo fallback below
    }

    return {
      id: 'dev-001',
      deviceId: 'INSPECT-UNIT-01',
      name: 'Inspection Unit - 01',
      deviceType: 'ESP32 Inspection Controller',
      ipAddress: '192.168.1.100',
      signalStrength: 'Strong',
      status: 'ONLINE',
      cameraStatus: 'ONLINE',
      cameraResolution: '1920 x 1080',
      cameraFps: 24,
      aiStatus: 'READY',
      ledStatus: true,
      ledBrightness: 75,
      uptime: '14h 32m',
      lastInspection: new Date().toISOString(),
    };
  }

  async setLED(state: boolean, brightness: number): Promise<{ success: boolean; message: string; device?: DeviceStatus }> {
    try {
      const res = await fetch('/api/device/led', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ state, brightness }),
      });
      if (res.ok) return await res.json();
    } catch {
      // demo fallback
    }
    return {
      success: true,
      message: `LED set to ${state ? 'ON' : 'OFF'} (${brightness}%)`,
    };
  }

  async reconnectDevice(): Promise<{ success: boolean; message: string }> {
    try {
      const res = await fetch('/api/device/reconnect', { method: 'POST' });
      if (res.ok) return await res.json();
    } catch {
      // demo fallback
    }
    return { success: true, message: 'ESP32 & Industrial Camera reconnected successfully.' };
  }

  // --- Inspection Service ---
  async startInspection(productId?: string): Promise<{ success: boolean; result: InspectionRecord }> {
    try {
      const res = await fetch('/api/inspection/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ device_id: 'INSPECT-UNIT-01', productId: productId || 'PCB-001' }),
      });
      if (res.ok) {
        const data = await res.json();
        return data;
      }
    } catch {
      // demo simulation
    }

    // High quality offline fallback generator
    const defects = ['Scratch', 'Missing Component', 'Crack', 'Wrong Component', 'Misalignment', 'Surface Defect'];
    const locations = ['Top Right', 'Center', 'Top Left', 'Bottom Right', 'Bottom Left'];
    const isPass = Math.random() > 0.3; // 70% pass, 30% fail on random live triggers
    const defectType = isPass ? 'None' : defects[Math.floor(Math.random() * defects.length)];
    const location = isPass ? 'None' : locations[Math.floor(Math.random() * locations.length)];
    const confidence = isPass ? +(0.95 + Math.random() * 0.048).toFixed(3) : +(0.88 + Math.random() * 0.11).toFixed(3);
    const severity = isPass ? 'NONE' : confidence > 0.95 ? 'HIGH' : confidence > 0.90 ? 'MEDIUM' : 'LOW';
    const insId = `INS-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(10000 + Math.random() * 90000)}`;

    const label = isPass ? `Normal ${(confidence * 100).toFixed(1)}%` : `${defectType} ${(confidence * 100).toFixed(1)}%`;
    const svgUrl = generatePcbSvg({ defectType, location, label, isPass });

    const mockRecord: InspectionRecord = {
      id: insId,
      inspectionId: insId,
      productId: productId || 'PCB-001',
      productName: 'Industrial Controller Motherboard V2',
      timestamp: new Date().toISOString(),
      result: isPass ? 'PASS' : 'FAIL',
      defect: defectType as any,
      confidence,
      location,
      severity: severity as any,
      model: 'YOLO Defect Detector v8.4',
      processingTimeMs: Math.floor(160 + Math.random() * 45),
      imageUrl: svgUrl,
      rawImageUrl: svgUrl,
      notes: isPass ? 'All solder joints and component positions nominal.' : `Anomalous ${defectType.toLowerCase()} flagged during neural inference scan.`,
      saved: true,
    };

    return { success: true, result: mockRecord };
  }

  async stopInspection(): Promise<{ success: boolean; message: string }> {
    try {
      const res = await fetch('/api/inspection/stop', { method: 'POST' });
      if (res.ok) return await res.json();
    } catch {
      // demo fallback
    }
    return { success: true, message: 'Inspection stopped.' };
  }

  async getLatestInspection(): Promise<InspectionRecord | null> {
    try {
      const res = await fetch('/api/inspection/latest');
      if (res.ok) {
        const data = await res.json();
        return data.inspection;
      }
    } catch {
      // demo fallback
    }
    return null;
  }

  async getInspectionHistory(filters?: { result?: string; defect?: string; search?: string; limit?: number }): Promise<InspectionRecord[]> {
    try {
      const params = new URLSearchParams();
      if (filters?.result) params.append('result', filters.result);
      if (filters?.defect) params.append('defect', filters.defect);
      if (filters?.search) params.append('search', filters.search);
      if (filters?.limit) params.append('limit', String(filters.limit));

      const res = await fetch(`/api/inspection/history?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        return data.inspections || [];
      }
    } catch {
      // demo fallback
    }
    return [];
  }

  async getInspectionDetails(id: string): Promise<InspectionRecord | null> {
    try {
      const res = await fetch(`/api/inspection/${id}`);
      if (res.ok) {
        const data = await res.json();
        return data.inspection;
      }
    } catch {
      // demo fallback
    }
    return null;
  }

  // --- Analytics Service ---
  async getAnalytics(): Promise<AnalyticsData> {
    try {
      const res = await fetch('/api/analytics');
      if (res.ok) {
        const data = await res.json();
        return data;
      }
    } catch {
      // demo fallback
    }

    return {
      totalInspections: 248,
      passCount: 221,
      failCount: 27,
      passRate: 89.1,
      failRate: 10.9,
      avgConfidence: 96.8,
      avgProcessingTimeMs: 174,
      defectDistribution: [
        { type: 'Scratch', count: 9, percentage: 33.3, color: '#f59e0b' },
        { type: 'Missing Component', count: 8, percentage: 29.6, color: '#ef4444' },
        { type: 'Crack', count: 5, percentage: 18.5, color: '#f43f5e' },
        { type: 'Wrong Component', count: 3, percentage: 11.1, color: '#a855f7' },
        { type: 'Surface / Misalignment', count: 2, percentage: 7.5, color: '#3b82f6' },
      ],
      dailyTrends: [
        { date: '01 Oct', total: 32, pass: 29, fail: 3 },
        { date: '02 Oct', total: 40, pass: 36, fail: 4 },
        { date: '03 Oct', total: 54, pass: 49, fail: 5 },
        { date: '04 Oct', total: 60, pass: 53, fail: 7 },
        { date: '05 Oct', total: 62, pass: 54, fail: 8 },
      ],
      severityBreakdown: [
        { severity: 'CRITICAL', count: 4 },
        { severity: 'HIGH', count: 11 },
        { severity: 'MEDIUM', count: 8 },
        { severity: 'LOW', count: 4 },
      ],
    };
  }

  // --- Products Service ---
  async getProducts(): Promise<ProductItem[]> {
    try {
      const res = await fetch('/api/products');
      if (res.ok) {
        const data = await res.json();
        return data.products;
      }
    } catch {
      // demo fallback
    }
    return [
      {
        id: 'p-01',
        productId: 'PCB-001',
        name: 'Industrial Controller Motherboard V2',
        category: 'Electronics / Mainboard',
        status: 'ACTIVE',
        supportedDefects: 'Scratch, Crack, Missing Component, Wrong Component, Surface Defect, Misalignment',
        inspectionCount: 142,
      },
      {
        id: 'p-02',
        productId: 'PCB-002',
        name: 'High-Voltage Power Regulator Board',
        category: 'Power Electronics',
        status: 'ACTIVE',
        supportedDefects: 'Scratch, Missing Component, Wrong Component, Misalignment',
        inspectionCount: 65,
      },
      {
        id: 'p-03',
        productId: 'PCB-003',
        name: 'Optical Sensor Transceiver Module',
        category: 'Optoelectronics',
        status: 'ACTIVE',
        supportedDefects: 'Scratch, Crack, Surface Defect, Damaged Component',
        inspectionCount: 28,
      },
      {
        id: 'p-04',
        productId: 'PCB-004',
        name: 'Wireless IoT Telemetry Node',
        category: 'RF / Communications',
        status: 'ACTIVE',
        supportedDefects: 'Missing Component, Wrong Component, Misalignment, Scratch',
        inspectionCount: 13,
      },
    ];
  }

  async addProduct(product: Partial<ProductItem>): Promise<ProductItem> {
    const res = await fetch('/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product),
    });
    const data = await res.json();
    return data.product;
  }

  // --- Alerts Service ---
  async getAlerts(): Promise<AlertItem[]> {
    try {
      const res = await fetch('/api/alerts');
      if (res.ok) {
        const data = await res.json();
        return data.alerts;
      }
    } catch {
      // demo fallback
    }
    return [];
  }

  // --- Settings Service ---
  async getSystemSettings(): Promise<AppSettings> {
    try {
      const res = await fetch('/api/settings');
      if (res.ok) {
        const data = await res.json();
        return data.settings;
      }
    } catch {
      // demo fallback
    }
    return {
      theme: 'dark',
      demoMode: true,
      notifications: true,
      confidenceThreshold: 70.0,
      autoSave: true,
      continuousInspection: false,
      backendUrl: 'http://192.168.1.100:8000/api',
      deviceId: 'INSPECT-UNIT-01',
    };
  }

  async updateSystemSettings(settings: Partial<AppSettings>): Promise<{ success: boolean; settings: AppSettings }> {
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });
      if (res.ok) return await res.json();
    } catch {
      // demo fallback
    }
    return { success: true, settings: settings as AppSettings };
  }
}

export const apiService = new ApiService();
