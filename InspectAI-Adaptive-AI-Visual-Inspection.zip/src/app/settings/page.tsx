'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Header } from '@/components/Header';
import { BottomNav } from '@/components/BottomNav';
import { useAuth } from '@/context/AuthContext';
import { apiService } from '@/services/apiService';
import { AppSettings, UserRole } from '@/lib/types';
import {
  Settings as SettingsIcon,
  User,
  Sliders,
  Cpu,
  Shield,
  LogOut,
  Save,
  CheckCircle2,
  Globe,
  SlidersHorizontal,
  Bell,
  Eye,
  Camera,
  Layers,
} from 'lucide-react';

export default function SettingsPage() {
  const router = useRouter();
  const { user, role, logout, switchRole } = useAuth();

  const [settings, setSettings] = useState<AppSettings>({
    theme: 'light',
    demoMode: true,
    notifications: true,
    confidenceThreshold: 70.0,
    autoSave: true,
    continuousInspection: false,
    backendUrl: 'http://192.168.1.100:8000/api',
    deviceId: 'INSPECT-UNIT-01',
  });

  const [saving, setSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  useEffect(() => {
    async function load() {
      const data = await apiService.getSystemSettings();
      if (data) setSettings(data);
    }
    load();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    apiService.setBaseUrl(settings.backendUrl);
    apiService.setDemoMode(settings.demoMode);
    await apiService.updateSystemSettings(settings);
    setSaving(false);
    setSuccessMessage('System configuration saved successfully.');
    setTimeout(() => setSuccessMessage(null), 3000);
  };

  const handleLogout = async () => {
    await logout();
    router.push('/');
  };

  return (
    <div className="min-h-screen bg-industrial-bg text-industrial-textDark pb-24 selection:bg-blue-600/10 selection:text-blue-600">
      <Header />

      <main className="max-w-2xl mx-auto px-4 py-4 space-y-4">
        {/* Title */}
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[11px] font-mono text-industrial-textMuted uppercase tracking-wider font-semibold">
              System Configuration
            </span>
            <h1 className="text-xl font-black text-industrial-textDark">Application Settings</h1>
          </div>

          <button
            onClick={handleLogout}
            className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 text-xs font-mono font-bold flex items-center gap-1.5 transition"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout</span>
          </button>
        </div>

        {successMessage && (
          <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-mono flex items-center gap-2 font-semibold">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{successMessage}</span>
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-4">
          {/* 1. Account & Role Section */}
          <div className="p-4 sm:p-5 rounded-2xl border border-industrial-border bg-white shadow-sm space-y-3">
            <div className="flex items-center gap-2">
              <User className="w-4 h-4 text-blue-600" />
              <h2 className="text-xs font-mono uppercase text-industrial-textDark font-bold tracking-wider">
                Operator Account
              </h2>
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-industrial-border">
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-industrial-textDark block">{user?.name || 'Administrator'}</span>
                <span className="text-[11px] font-mono text-industrial-textMuted block">{user?.email || 'admin@inspectai.com'}</span>
              </div>

              <div className="flex items-center gap-1">
                {(['ADMIN', 'OPERATOR', 'VIEWER'] as UserRole[]).map((r) => (
                  <button
                    type="button"
                    key={r}
                    onClick={() => switchRole(r)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold transition ${
                      role === r
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'bg-white text-industrial-textDark hover:bg-slate-100 border border-industrial-border'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 2. AI Model & Defect Threshold Section */}
          <div className="p-4 sm:p-5 rounded-2xl border border-industrial-border bg-white shadow-sm space-y-3">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-emerald-600" />
              <h2 className="text-xs font-mono uppercase text-industrial-textDark font-bold tracking-wider">
                AI Vision Model & Thresholds
              </h2>
            </div>

            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-slate-50 border border-industrial-border flex items-center justify-between text-xs font-mono">
                <span className="text-industrial-textMuted font-semibold">Model Engine:</span>
                <span className="text-industrial-textDark font-bold">YOLO Defect Detector v8.4</span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-industrial-border space-y-2">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-industrial-textDark font-semibold">Confidence Threshold:</span>
                  <span className="text-emerald-700 font-bold">{settings.confidenceThreshold}%</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="99"
                  value={settings.confidenceThreshold}
                  onChange={(e) =>
                    setSettings({ ...settings, confidenceThreshold: Number(e.target.value) })
                  }
                  className="w-full h-2.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
                <div className="flex justify-between text-[10px] font-mono text-industrial-textMuted">
                  <span>50% (High Recall)</span>
                  <span>75% (Balanced)</span>
                  <span>99% (High Precision)</span>
                </div>
              </div>
            </div>
          </div>

          {/* 3. Device & Backend Network Section */}
          <div className="p-4 sm:p-5 rounded-2xl border border-industrial-border bg-white shadow-sm space-y-3">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-blue-600" />
              <h2 className="text-xs font-mono uppercase text-industrial-textDark font-bold tracking-wider">
                Edge Computer & REST Backend API
              </h2>
            </div>

            <div>
              <label className="block text-xs font-mono text-industrial-textDark font-semibold mb-1.5">
                Backend REST Base URL (Configurable)
              </label>
              <input
                type="text"
                value={settings.backendUrl}
                onChange={(e) => setSettings({ ...settings, backendUrl: e.target.value })}
                placeholder="http://192.168.1.100:8000/api"
                className="w-full px-3 py-2 text-xs rounded-xl border border-industrial-border bg-slate-50 text-industrial-textDark font-mono focus:outline-none focus:ring-1 focus:ring-blue-600"
              />
              <span className="text-[10px] text-industrial-textMuted font-mono block mt-1">
                Point to your edge computer / AI inference server. Never hardcoded.
              </span>
            </div>
          </div>

          {/* 4. Operational Toggles */}
          <div className="p-4 sm:p-5 rounded-2xl border border-industrial-border bg-white shadow-sm space-y-3">
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-amber-600" />
              <h2 className="text-xs font-mono uppercase text-industrial-textDark font-bold tracking-wider">
                Operational Toggles
              </h2>
            </div>

            <div className="space-y-2">
              <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-industrial-border cursor-pointer">
                <div>
                  <span className="text-xs font-bold text-industrial-textDark block font-mono">
                    DEMO / OFFLINE MODE
                  </span>
                  <span className="text-[11px] text-industrial-textMuted block">
                    Use built-in simulated edge inference when physical hardware is disconnected
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.demoMode}
                  onChange={(e) => setSettings({ ...settings, demoMode: e.target.checked })}
                  className="w-4 h-4 accent-blue-600 cursor-pointer rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-industrial-border cursor-pointer">
                <div>
                  <span className="text-xs font-bold text-industrial-textDark block font-mono">
                    Auto-Save Inspection Records
                  </span>
                  <span className="text-[11px] text-industrial-textMuted block">
                    Immediately archive all PASS/FAIL telemetry to database
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.autoSave}
                  onChange={(e) => setSettings({ ...settings, autoSave: e.target.checked })}
                  className="w-4 h-4 accent-blue-600 cursor-pointer rounded"
                />
              </label>
            </div>
          </div>

          {/* Save Button */}
          <button
            type="submit"
            disabled={saving}
            className="w-full py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 font-bold text-xs font-mono text-white shadow-md shadow-blue-600/20 flex items-center justify-center gap-2 transition"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'SAVING CONFIGURATION...' : 'SAVE ALL SETTINGS'}</span>
          </button>
        </form>
      </main>

      <BottomNav />
    </div>
  );
}
