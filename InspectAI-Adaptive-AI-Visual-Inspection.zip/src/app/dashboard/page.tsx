'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import { apiService } from '@/services/apiService';
import { Header } from '@/components/Header';
import { BottomNav } from '@/components/BottomNav';
import { StatusCard } from '@/components/StatusCard';
import { InspectionCard } from '@/components/InspectionCard';
import { DeviceStatus, AnalyticsData, InspectionRecord } from '@/lib/types';
import {
  Camera,
  Cpu,
  Lightbulb,
  Radio,
  Play,
  ArrowRight,
  TrendingUp,
  CheckCircle2,
  XCircle,
  Database,
  History,
  Eye,
  Activity,
  Layers,
} from 'lucide-react';

export default function DashboardPage() {
  const router = useRouter();
  const { user, role } = useAuth();

  const [device, setDevice] = useState<DeviceStatus | null>(null);
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [latestInspection, setLatestInspection] = useState<InspectionRecord | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      try {
        const [devData, anaData, insData] = await Promise.all([
          apiService.getDeviceStatus(),
          apiService.getAnalytics(),
          apiService.getLatestInspection(),
        ]);
        setDevice(devData);
        setAnalytics(anaData);
        setLatestInspection(insData);
      } catch (err) {
        console.error('Failed to load dashboard data:', err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const passRate = analytics?.passRate || 89.1;
  const passCount = analytics?.passCount || 221;
  const failCount = analytics?.failCount || 27;
  const totalCount = analytics?.totalInspections || 248;

  return (
    <div className="min-h-screen bg-industrial-bg text-industrial-textDark pb-24 selection:bg-blue-600/10 selection:text-blue-600">
      <Header />

      <main className="max-w-2xl mx-auto px-4 py-4 sm:py-6 space-y-5">
        {/* Machine Online Summary Banner */}
        <div className="p-4 sm:p-5 rounded-2xl border border-industrial-border bg-white shadow-sm space-y-4">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <span className="text-[11px] font-mono text-industrial-textMuted uppercase tracking-wider font-semibold">
                Good Morning, {user?.name?.split(' ')[0] || 'Operator'}
              </span>
              <h1 className="text-xl sm:text-2xl font-black tracking-tight text-industrial-textDark flex items-center gap-2">
                <span>{device?.name || 'Inspection Unit - 01'}</span>
              </h1>
              <div className="flex items-center gap-2 text-xs font-mono text-industrial-textMuted">
                <span className="flex items-center gap-1.5 text-emerald-600 font-bold">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]" />
                  ONLINE
                </span>
                <span>•</span>
                <span>ESP32 Node ({device?.ipAddress || '192.168.1.100'})</span>
              </div>
            </div>

            <span className="px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200 text-xs font-mono font-bold">
              REV 4.2
            </span>
          </div>

          {/* 4 Status Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
            <StatusCard
              title="Camera"
              status={device?.cameraStatus || 'ONLINE'}
              subtext="1920x1080 24fps"
              icon={Camera}
            />
            <StatusCard
              title="AI Engine"
              status={device?.aiStatus || 'READY'}
              subtext="YOLOv8 Core"
              icon={Cpu}
            />
            <StatusCard
              title="LED Light"
              status={device?.ledStatus ? 'ON' : 'OFF'}
              subtext={`${device?.ledBrightness || 75}% Brightness`}
              icon={Lightbulb}
            />
            <StatusCard
              title="Control Unit"
              status="CONNECTED"
              subtext="ESP32 (Wi-Fi)"
              icon={Radio}
            />
          </div>
        </div>

        {/* Primary Action Button: Start Inspection */}
        <div className="space-y-2">
          <button
            onClick={() => router.push('/inspect')}
            className="w-full py-4 px-6 rounded-2xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 font-black text-base sm:text-lg text-white shadow-md shadow-blue-600/20 flex items-center justify-center gap-3 transition-all duration-150 group"
          >
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Play className="w-5 h-5 text-white fill-white" />
            </div>
            <span className="tracking-wide uppercase font-mono">START INSPECTION</span>
            <ArrowRight className="w-5 h-5 text-white/90 group-hover:translate-x-1 transition-transform" />
          </button>

          <div className="grid grid-cols-3 gap-2">
            <Link
              href={latestInspection ? `/result/${latestInspection.id}` : '/inspect'}
              className="py-2.5 px-2 rounded-xl bg-white hover:bg-slate-50 border border-industrial-border text-xs font-mono text-industrial-textDark font-semibold flex items-center justify-center gap-1.5 transition shadow-sm"
            >
              <Eye className="w-3.5 h-3.5 text-blue-600" />
              <span>Latest Result</span>
            </Link>
            <Link
              href="/dataset"
              className="py-2.5 px-2 rounded-xl bg-white hover:bg-slate-50 border border-industrial-border text-xs font-mono text-industrial-textDark font-semibold flex items-center justify-center gap-1.5 transition shadow-sm"
            >
              <Database className="w-3.5 h-3.5 text-amber-600" />
              <span>Synthetic AI</span>
            </Link>
            <Link
              href="/history"
              className="py-2.5 px-2 rounded-xl bg-white hover:bg-slate-50 border border-industrial-border text-xs font-mono text-industrial-textDark font-semibold flex items-center justify-center gap-1.5 transition shadow-sm"
            >
              <History className="w-3.5 h-3.5 text-emerald-600" />
              <span>History</span>
            </Link>
          </div>
        </div>

        {/* Today's Inspections Analytics Card */}
        <div className="p-4 sm:p-5 rounded-2xl border border-industrial-border bg-white shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[11px] font-mono uppercase text-industrial-textMuted tracking-wider font-semibold">
                Production Overview
              </span>
              <h2 className="text-base font-bold text-industrial-textDark">Today&apos;s Inspections</h2>
            </div>
            <Link
              href="/analytics"
              className="text-xs font-mono text-blue-600 font-bold hover:underline flex items-center gap-1"
            >
              <span>Full Analytics</span>
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>

          {/* Metric Row */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3 rounded-xl bg-slate-50 border border-industrial-border">
              <span className="text-[11px] font-mono text-industrial-textMuted font-semibold block">Total Checked</span>
              <span className="text-xl sm:text-2xl font-black text-industrial-textDark font-mono">
                {totalCount}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-emerald-50/50 border border-emerald-200">
              <span className="text-[11px] font-mono text-emerald-700 font-bold block flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" /> PASS
              </span>
              <span className="text-xl sm:text-2xl font-black text-emerald-700 font-mono">
                {passCount}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-rose-50/50 border border-rose-200">
              <span className="text-[11px] font-mono text-rose-700 font-bold block flex items-center gap-1">
                <XCircle className="w-3 h-3 text-rose-600" /> FAIL
              </span>
              <span className="text-xl sm:text-2xl font-black text-rose-700 font-mono">
                {failCount}
              </span>
            </div>
          </div>

          {/* Pass Rate Progress Bar */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-industrial-textMuted font-medium">Pass Rate Yield</span>
              <span className="text-emerald-700 font-bold">{passRate}%</span>
            </div>
            <div className="w-full h-3 rounded-full bg-slate-100 overflow-hidden flex border border-industrial-border">
              <div
                className="h-full bg-emerald-600 transition-all duration-500"
                style={{ width: `${passRate}%` }}
              />
              <div
                className="h-full bg-rose-600 transition-all duration-500"
                style={{ width: `${100 - passRate}%` }}
              />
            </div>
          </div>
        </div>

        {/* Latest Inspection Highlight */}
        {latestInspection && (
          <div className="space-y-2">
            <div className="flex items-center justify-between px-1">
              <span className="text-xs font-mono uppercase text-industrial-textMuted font-bold">
                Latest Optical Inspection
              </span>
              <span className="text-[11px] font-mono text-industrial-textMuted font-medium">
                {new Date(latestInspection.timestamp).toLocaleTimeString()}
              </span>
            </div>

            <InspectionCard
              inspection={latestInspection}
              onClick={() => router.push(`/result/${latestInspection.id}`)}
            />
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
}
