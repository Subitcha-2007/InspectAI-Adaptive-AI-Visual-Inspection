import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET() {
  try {
    const products = await prisma.product.findMany({
      include: {
        _count: {
          select: { inspections: true },
        },
      },
    });

    const mapped = products.map(p => ({
      id: p.id,
      productId: p.productId,
      name: p.name,
      category: p.category,
      status: p.status,
      supportedDefects: p.supportedDefects,
      specifications: p.specifications,
      inspectionCount: p._count.inspections,
    }));

    return NextResponse.json({ success: true, products: mapped });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch products' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { productId, name, category, status, supportedDefects, specifications } = body;

    if (!productId || !name) {
      return NextResponse.json({ error: 'Product ID and Name are required' }, { status: 400 });
    }

    const product = await prisma.product.create({
      data: {
        productId: productId.trim().toUpperCase(),
        name: name.trim(),
        category: category || 'Electronics / PCB',
        status: status || 'ACTIVE',
        supportedDefects: supportedDefects || 'Scratch, Crack, Missing Component, Wrong Component',
        specifications: typeof specifications === 'object' ? JSON.stringify(specifications) : specifications,
      },
    });

    return NextResponse.json({ success: true, product });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to create product' }, { status: 500 });
  }
}
