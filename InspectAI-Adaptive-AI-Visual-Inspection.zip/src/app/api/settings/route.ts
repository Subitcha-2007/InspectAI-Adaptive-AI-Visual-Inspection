import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getAuthenticatedUser } from '@/lib/auth';

export async function GET(req: NextRequest) {
  try {
    const user = await getAuthenticatedUser(req);
    let settings = null;

    if (user?.id) {
      settings = await prisma.userSettings.findUnique({
        where: { userId: user.id },
      });
    }

    if (!settings) {
      settings = await prisma.userSettings.findFirst();
    }

    return NextResponse.json({
      success: true,
      settings: settings || {
        theme: 'dark',
        demoMode: true,
        notifications: true,
        confidenceThreshold: 70.0,
        autoSave: true,
        continuousInspection: false,
        backendUrl: 'http://192.168.1.100:8000/api',
        deviceId: 'INSPECT-UNIT-01',
      },
    });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch settings' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const user = await getAuthenticatedUser(req);

    const userId = user?.id || (await prisma.user.findFirst())?.id;

    if (!userId) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const settings = await prisma.userSettings.upsert({
      where: { userId },
      update: {
        theme: body.theme,
        demoMode: body.demoMode,
        notifications: body.notifications,
        confidenceThreshold: body.confidenceThreshold,
        autoSave: body.autoSave,
        continuousInspection: body.continuousInspection,
        backendUrl: body.backendUrl,
      },
      create: {
        userId,
        theme: body.theme || 'dark',
        demoMode: body.demoMode ?? true,
        notifications: body.notifications ?? true,
        confidenceThreshold: body.confidenceThreshold || 70.0,
        autoSave: body.autoSave ?? true,
        continuousInspection: body.continuousInspection ?? false,
        backendUrl: body.backendUrl || 'http://192.168.1.100:8000/api',
      },
    });

    return NextResponse.json({ success: true, settings });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to update settings' }, { status: 500 });
  }
}
