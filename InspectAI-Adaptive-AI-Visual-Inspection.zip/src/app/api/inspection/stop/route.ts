import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function POST() {
  try {
    await prisma.device.updateMany({
      where: { deviceId: 'INSPECT-UNIT-01' },
      data: { aiStatus: 'READY' },
    });

    return NextResponse.json({
      success: true,
      message: 'Continuous inspection cycle stopped successfully.',
    });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to stop inspection' }, { status: 500 });
  }
}
