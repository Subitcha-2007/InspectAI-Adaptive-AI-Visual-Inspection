import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params;
    const inspection = await prisma.inspection.findFirst({
      where: {
        OR: [
          { id },
          { inspectionId: id },
        ],
      },
      include: { product: true },
    });

    if (!inspection) {
      return NextResponse.json({ error: 'Inspection record not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true, inspection });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch inspection details' }, { status: 500 });
  }
}
