import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET() {
  try {
    const inspection = await prisma.inspection.findFirst({
      orderBy: { timestamp: 'desc' },
      include: { product: true },
    });

    return NextResponse.json({
      success: true,
      inspection,
    });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch latest inspection' }, { status: 500 });
  }
}
