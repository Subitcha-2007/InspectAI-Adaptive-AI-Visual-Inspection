import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const result = searchParams.get('result');
    const defect = searchParams.get('defect');
    const search = searchParams.get('search');
    const limit = parseInt(searchParams.get('limit') || '100', 10);

    const whereClause: any = {};

    if (result && result !== 'ALL') {
      whereClause.result = result.toUpperCase();
    }

    if (defect && defect !== 'ALL') {
      whereClause.defect = defect;
    }

    if (search && search.trim()) {
      const q = search.trim();
      whereClause.OR = [
        { productId: { contains: q } },
        { inspectionId: { contains: q } },
        { productName: { contains: q } },
        { defect: { contains: q } },
      ];
    }

    const inspections = await prisma.inspection.findMany({
      where: whereClause,
      orderBy: { timestamp: 'desc' },
      take: limit,
      include: { product: true },
    });

    return NextResponse.json({
      success: true,
      count: inspections.length,
      inspections,
    });
  } catch (error) {
    console.error('History API error:', error);
    return NextResponse.json({ error: 'Failed to fetch inspection history' }, { status: 500 });
  }
}
