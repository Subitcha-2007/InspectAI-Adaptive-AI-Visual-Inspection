import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { generatePcbSvg } from '@/lib/svgGenerator';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const { device_id, productId } = body;

    const prodId = productId || 'PCB-001';
    const product = await prisma.product.findUnique({
      where: { productId: prodId },
    });
    const productName = product ? product.name : 'Industrial Controller Motherboard V2';

    // Simulate Deep Learning Vision Inference Engine (YOLO Defect Detector)
    const defects = [
      { name: 'Missing Component', loc: 'Top Right', sev: 'HIGH', note: 'SMD capacitor C14 missing on trace bus.' },
      { name: 'Scratch', loc: 'Center', sev: 'MEDIUM', note: 'Copper mask surface scratch across signal track.' },
      { name: 'Crack', loc: 'Top Left', sev: 'CRITICAL', note: 'Micro-fracture detected in FR4 base substrate.' },
      { name: 'Misalignment', loc: 'Bottom Left', sev: 'MEDIUM', note: 'QFN chip rotated 14° out of tolerance.' },
      { name: 'Wrong Component', loc: 'Bottom Right', sev: 'HIGH', note: '10k resistor loaded instead of 100k.' },
      { name: 'Surface Defect', loc: 'Center', sev: 'LOW', note: 'Flux residue puddle near microcontroller.' },
    ];

    // 85% PASS, 15% FAIL realistic industrial baseline
    const isPass = Math.random() > 0.35;
    const chosenDefect = isPass ? null : defects[Math.floor(Math.random() * defects.length)];

    const result = isPass ? 'PASS' : 'FAIL';
    const defect = isPass ? 'None' : (chosenDefect?.name || 'Unknown Defect');
    const location = isPass ? 'None' : (chosenDefect?.loc || 'Center');
    const severity = isPass ? 'NONE' : (chosenDefect?.sev || 'MEDIUM');
    const confidence = isPass
      ? +(0.96 + Math.random() * 0.038).toFixed(3)
      : +(0.89 + Math.random() * 0.098).toFixed(3);
    const processingTimeMs = Math.floor(155 + Math.random() * 50);

    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
    const randSuffix = Math.floor(10000 + Math.random() * 90000);
    const inspectionId = `INS-${dateStr}-${randSuffix}`;

    const label = isPass
      ? `Normal ${(confidence * 100).toFixed(1)}%`
      : `${defect} ${(confidence * 100).toFixed(1)}%`;

    const imageUrl = generatePcbSvg({
      defectType: defect,
      location,
      label,
      isPass,
    });

    let boxX = 260, boxY = 145, boxW = 140, boxH = 100;
    if (location === 'Top Right') { boxX = 460; boxY = 60; boxW = 120; boxH = 90; }
    else if (location === 'Top Left') { boxX = 60; boxY = 60; boxW = 130; boxH = 95; }
    else if (location === 'Center') { boxX = 260; boxY = 145; boxW = 150; boxH = 105; }
    else if (location === 'Bottom Right') { boxX = 450; boxY = 240; boxW = 130; boxH = 90; }
    else if (location === 'Bottom Left') { boxX = 70; boxY = 230; boxW = 120; boxH = 90; }

    const boundingBoxes = [
      {
        x: boxX,
        y: boxY,
        w: boxW,
        h: boxH,
        label,
        confidence,
        color: isPass ? '#22c55e' : '#ef4444',
      },
    ];

    const notes = isPass
      ? 'All automated optical defect checks passed with high confidence.'
      : chosenDefect?.note || `Defect ${defect} identified.`;

    const inspection = await prisma.inspection.create({
      data: {
        inspectionId,
        productId: prodId,
        productName,
        timestamp: now,
        result,
        defect,
        confidence,
        location,
        severity,
        model: 'YOLO Defect Detector v8.4',
        processingTimeMs,
        imageUrl,
        rawImageUrl: imageUrl,
        boundingBoxesJson: JSON.stringify(boundingBoxes),
        notes,
        saved: true,
      },
    });

    // Update device last inspection
    await prisma.device.updateMany({
      where: { deviceId: 'INSPECT-UNIT-01' },
      data: { lastInspection: now },
    });

    // If fail, create alert
    if (!isPass) {
      await prisma.alert.create({
        data: {
          title: `Defect Detected: ${defect}`,
          message: `${productName} (${inspectionId}) failed with ${defect} at ${location} (${(confidence * 100).toFixed(1)}%).`,
          type: severity === 'CRITICAL' ? 'ERROR' : 'WARNING',
          source: 'AI Model',
          timestamp: now,
        },
      });
    }

    return NextResponse.json({
      success: true,
      inspection_id: inspection.inspectionId,
      status: inspection.result,
      defect: inspection.defect,
      confidence: inspection.confidence,
      location: inspection.location,
      severity: inspection.severity,
      image_url: inspection.imageUrl,
      processing_time_ms: inspection.processingTimeMs,
      result: inspection,
    });
  } catch (error) {
    console.error('Start inspection error:', error);
    return NextResponse.json({ error: 'Failed to complete inspection' }, { status: 500 });
  }
}
