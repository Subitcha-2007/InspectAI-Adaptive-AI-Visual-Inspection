import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function POST() {
  try {
    await prisma.device.updateMany({
      where: { deviceId: 'INSPECT-UNIT-01' },
      data: {
        status: 'ONLINE',
        cameraStatus: 'ONLINE',
        aiStatus: 'READY',
        signalStrength: 'Strong',
      },
    });

    await prisma.alert.create({
      data: {
        title: 'Hardware Reconnected',
        message: 'ESP32 Controller & Industrial Camera link verified over Wi-Fi (192.168.1.100).',
        type: 'SUCCESS',
        source: 'ESP32',
      },
    });

    return NextResponse.json({
      success: true,
      message: 'ESP32 Control Unit and Camera reconnected successfully.',
    });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to reconnect hardware' }, { status: 500 });
  }
}
