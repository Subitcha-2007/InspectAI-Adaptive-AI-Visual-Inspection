import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { state, brightness } = body;

    const updated = await prisma.device.updateMany({
      where: { deviceId: 'INSPECT-UNIT-01' },
      data: {
        ledStatus: typeof state === 'boolean' ? state : true,
        ledBrightness: typeof brightness === 'number' ? Math.max(0, Math.min(100, brightness)) : 75,
      },
    });

    const device = await prisma.device.findFirst({
      where: { deviceId: 'INSPECT-UNIT-01' },
    });

    return NextResponse.json({
      success: true,
      message: `LED brightness updated to ${brightness}% (${state ? 'ON' : 'OFF'})`,
      device,
    });
  } catch (error) {
    console.error('LED control error:', error);
    return NextResponse.json({ error: 'Failed to update LED status' }, { status: 500 });
  }
}
