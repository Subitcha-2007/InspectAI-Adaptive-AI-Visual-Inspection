import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET() {
  try {
    let device = await prisma.device.findFirst({
      where: { deviceId: 'INSPECT-UNIT-01' },
    });

    if (!device) {
      device = await prisma.device.create({
        data: {
          deviceId: 'INSPECT-UNIT-01',
          name: 'Inspection Unit - 01',
          deviceType: 'ESP32 Inspection Controller',
          ipAddress: '192.168.1.100',
          signalStrength: 'Strong',
          status: 'ONLINE',
          cameraStatus: 'ONLINE',
          cameraResolution: '1920 x 1080',
          cameraFps: 24,
          aiStatus: 'READY',
          ledStatus: true,
          ledBrightness: 75,
          uptime: '14h 32m',
          lastInspection: new Date(),
        },
      });
    }

    return NextResponse.json({
      success: true,
      device,
    });
  } catch (error) {
    console.error('Device status error:', error);
    return NextResponse.json({ error: 'Failed to retrieve device status' }, { status: 500 });
  }
}
