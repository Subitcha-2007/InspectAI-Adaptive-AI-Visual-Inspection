import type { Metadata, Viewport } from 'next';
import './globals.css';
import { AuthProvider } from '@/context/AuthContext';
import { ToastProvider } from '@/context/ToastContext';

export const metadata: Metadata = {
  title: 'InspectAI | Low-Cost Adaptive AI Visual Inspection System',
  description: 'Industrial automated optical inspection (AOI) platform using Deep Learning (YOLO), synthetic data augmentation, and ESP32 IoT control.',
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-industrial-bg text-industrial-textDark antialiased selection:bg-blue-600/10 selection:text-blue-600 font-sans min-h-screen">
        <AuthProvider>
          <ToastProvider>
            {children}
          </ToastProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
