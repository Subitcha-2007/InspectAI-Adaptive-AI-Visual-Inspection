'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Header } from '@/components/Header';
import { BottomNav } from '@/components/BottomNav';
import { InspectionCard } from '@/components/InspectionCard';
import { apiService } from '@/services/apiService';
import { InspectionRecord } from '@/lib/types';
import {
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Calendar,
  Layers,
  Sparkles,
  RefreshCw,
  Clock,
} from 'lucide-react';

export default function InspectionHistoryPage() {
  const router = useRouter();

  const [inspections, setInspections] = useState<InspectionRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'PASS' | 'FAIL'>('ALL');
  const [defectFilter, setDefectFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const defectOptions = [
    'ALL',
    'Scratch',
    'Crack',
    'Missing Component',
    'Wrong Component',
    'Surface Defect',
    'Damaged Component',
    'Misalignment',
  ];

  const fetchHistory = async () => {
    setLoading(true);
    const data = await apiService.getInspectionHistory({
      result: statusFilter !== 'ALL' ? statusFilter : undefined,
      defect: defectFilter !== 'ALL' ? defectFilter : undefined,
      search: searchQuery || undefined,
    });
    setInspections(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchHistory();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusFilter, defectFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchHistory();
  };

  return (
    <div className="min-h-screen bg-industrial-bg text-industrial-textDark pb-24 selection:bg-blue-600/10 selection:text-blue-600">
      <Header />

      <main className="max-w-2xl mx-auto px-4 py-4 space-y-4">
        {/* Title Header */}
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[11px] font-mono text-industrial-textMuted uppercase tracking-wider font-semibold">
              Quality Records
            </span>
            <h1 className="text-xl font-black text-industrial-textDark">Inspection History</h1>
          </div>
          <span className="px-2.5 py-1 rounded-full bg-white border border-industrial-border text-xs font-mono font-bold text-industrial-textDark shadow-sm">
            {inspections.length} Records
          </span>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearchSubmit} className="relative">
          <Search className="w-4 h-4 text-industrial-textMuted absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by Product ID, Inspection ID, or Defect..."
            className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm rounded-xl border border-industrial-border bg-white text-industrial-textDark placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 font-mono shadow-sm"
          />
        </form>

        {/* Status Filter Tabs */}
        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => setStatusFilter('ALL')}
            className={`py-2 px-3 rounded-xl text-xs font-mono font-bold transition ${
              statusFilter === 'ALL'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-white text-industrial-textDark hover:bg-slate-50 border border-industrial-border shadow-sm'
            }`}
          >
            ALL
          </button>
          <button
            onClick={() => setStatusFilter('PASS')}
            className={`py-2 px-3 rounded-xl text-xs font-mono font-bold transition flex items-center justify-center gap-1.5 ${
              statusFilter === 'PASS'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-white text-emerald-700 hover:bg-emerald-50 border border-emerald-200 shadow-sm'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            PASS
          </button>
          <button
            onClick={() => setStatusFilter('FAIL')}
            className={`py-2 px-3 rounded-xl text-xs font-mono font-bold transition flex items-center justify-center gap-1.5 ${
              statusFilter === 'FAIL'
                ? 'bg-rose-600 text-white shadow-sm'
                : 'bg-white text-rose-700 hover:bg-rose-50 border border-rose-200 shadow-sm'
            }`}
          >
            <XCircle className="w-3.5 h-3.5" />
            FAIL
          </button>
        </div>

        {/* Defect Class Filter Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs font-mono no-scrollbar">
          <span className="text-[11px] text-industrial-textMuted mr-1 flex items-center gap-1 font-bold">
            <Filter className="w-3 h-3" /> Defect:
          </span>
          {defectOptions.map((opt) => (
            <button
              key={opt}
              onClick={() => setDefectFilter(opt)}
              className={`px-2.5 py-1 rounded-lg whitespace-nowrap text-[11px] transition ${
                defectFilter === opt
                  ? 'bg-blue-600 text-white font-bold'
                  : 'bg-white text-industrial-textDark hover:bg-slate-50 border border-industrial-border'
              }`}
            >
              {opt}
            </button>
          ))}
        </div>

        {/* Inspection List */}
        {loading ? (
          <div className="py-12 flex flex-col items-center justify-center text-industrial-textMuted gap-2">
            <RefreshCw className="w-6 h-6 animate-spin text-blue-600" />
            <span className="text-xs font-mono font-semibold">Fetching historical inspection logs...</span>
          </div>
        ) : inspections.length === 0 ? (
          <div className="p-8 rounded-2xl border border-dashed border-industrial-border bg-white text-center text-industrial-textMuted space-y-2">
            <Layers className="w-8 h-8 mx-auto text-slate-400" />
            <p className="text-xs font-mono">No matching inspection records found.</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {inspections.map((item) => (
              <InspectionCard
                key={item.id}
                inspection={item}
                onClick={() => router.push(`/result/${item.id}`)}
              />
            ))}
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
}
