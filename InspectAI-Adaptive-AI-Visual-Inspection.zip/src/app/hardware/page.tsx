'use client';

import React, { useState, useEffect } from 'react';
import { Header } from '@/components/Header';
import { BottomNav } from '@/components/BottomNav';
import { apiService } from '@/services/apiService';
import { DeviceStatus } from '@/lib/types';
import {
  Radio,
  Camera,
  Lightbulb,
  Wifi,
  RefreshCw,
  Sliders,
  Power,
  Zap,
  CheckCircle2,
  AlertCircle,
  Activity,
} from 'lucide-react';

export default function HardwarePage() {
  const [device, setDevice] = useState<DeviceStatus | null>(null);
  const [ledState, setLedState] = useState(true);
  const [brightness, setBrightness] = useState(75);
  const [isReconnecting, setIsReconnecting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  useEffect(() => {
    async function load() {
      const data = await apiService.getDeviceStatus();
      if (data) {
        setDevice(data);
        setLedState(data.ledStatus);
        setBrightness(data.ledBrightness);
      }
    }
    load();
  }, []);

  const handleBrightnessChange = async (val: number) => {
    setBrightness(val);
    await apiService.setLED(ledState, val);
  };

  const handleToggleLED = async (state: boolean) => {
    setLedState(state);
    await apiService.setLED(state, brightness);
    setStatusMessage(`Ring LED switched ${state ? 'ON' : 'OFF'} (${brightness}%)`);
    setTimeout(() => setStatusMessage(null), 3000);
  };

  const handleReconnect = async () => {
    setIsReconnecting(true);
    setStatusMessage('Handshaking with ESP32 & Industrial Camera Optic...');
    await apiService.reconnectDevice();
    setIsReconnecting(false);
    setStatusMessage('ESP32 and Camera link active & synchronized!');
    setTimeout(() => setStatusMessage(null), 3500);
  };

  return (
    <div className="min-h-screen bg-industrial-bg text-industrial-textDark pb-24 selection:bg-blue-600/10 selection:text-blue-600">
      <Header />

      <main className="max-w-2xl mx-auto px-4 py-4 space-y-4">
        {/* Title */}
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[11px] font-mono text-industrial-textMuted uppercase tracking-wider font-semibold">
              Physical Peripherals
            </span>
            <h1 className="text-xl font-black text-industrial-textDark">Hardware & ESP32 Control</h1>
          </div>

          <button
            onClick={handleReconnect}
            disabled={isReconnecting}
            className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-50 border border-industrial-border text-xs font-mono text-blue-600 font-bold flex items-center gap-1.5 transition shadow-sm"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isReconnecting ? 'animate-spin' : ''}`} />
            <span>Reconnect</span>
          </button>
        </div>

        {/* Status Message */}
        {statusMessage && (
          <div className="p-3.5 rounded-xl bg-blue-50 border border-blue-200 text-blue-800 text-xs font-mono flex items-center gap-2 font-semibold">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{statusMessage}</span>
          </div>
        )}

        {/* 1. ESP32 Control Unit Card */}
        <div className="p-4 sm:p-5 rounded-2xl border border-industrial-border bg-white shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-blue-50 border border-blue-200 text-blue-600">
                <Radio className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-sm font-bold text-industrial-textDark font-mono uppercase">
                  Control Unit (ESP32)
                </h2>
                <p className="text-xs text-industrial-textMuted">Inspection Bed Controller & Trigger Node</p>
              </div>
            </div>

            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-mono font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_6px_#10b981]" />
              CONNECTED
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1 text-xs font-mono">
            <div className="p-2.5 rounded-xl bg-slate-50 border border-industrial-border">
              <span className="text-industrial-textMuted block text-[11px] font-semibold">Device IP</span>
              <span className="font-bold text-industrial-textDark">{device?.ipAddress || '192.168.1.100'}</span>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-50 border border-industrial-border">
              <span className="text-industrial-textMuted block text-[11px] font-semibold">Wi-Fi Signal</span>
              <span className="font-bold text-emerald-700">Strong (-42 dBm)</span>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-50 border border-industrial-border col-span-2 sm:col-span-1">
              <span className="text-industrial-textMuted block text-[11px] font-semibold">System Uptime</span>
              <span className="font-bold text-industrial-textDark">{device?.uptime || '14h 32m'}</span>
            </div>
          </div>
        </div>

        {/* 2. Industrial Camera Card */}
        <div className="p-4 sm:p-5 rounded-2xl border border-industrial-border bg-white shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-blue-50 border border-blue-200 text-blue-600">
                <Camera className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-sm font-bold text-industrial-textDark font-mono uppercase">
                  Industrial Camera Optic
                </h2>
                <p className="text-xs text-industrial-textMuted">GigE / USB3 Vision High-Resolution Sensor</p>
              </div>
            </div>

            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-mono font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_6px_#10b981]" />
              ONLINE
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2.5 pt-1 text-xs font-mono">
            <div className="p-2.5 rounded-xl bg-slate-50 border border-industrial-border">
              <span className="text-industrial-textMuted block text-[11px] font-semibold">Resolution</span>
              <span className="font-bold text-industrial-textDark">1920 x 1080 (FHD)</span>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-50 border border-industrial-border">
              <span className="text-industrial-textMuted block text-[11px] font-semibold">Frame Rate</span>
              <span className="font-bold text-industrial-textDark">24 FPS Steady</span>
            </div>
          </div>

          <button
            onClick={() => {
              setStatusMessage('Camera calibration test passed (0 frame drop).');
              setTimeout(() => setStatusMessage(null), 3000);
            }}
            className="w-full py-2.5 px-3 rounded-xl bg-slate-50 hover:bg-slate-100 border border-industrial-border text-xs font-mono text-industrial-textDark font-bold flex items-center justify-center gap-2 transition"
          >
            <Camera className="w-3.5 h-3.5 text-blue-600" />
            <span>Run Camera Self-Test</span>
          </button>
        </div>

        {/* 3. Ring LED Light & Brightness Control Card */}
        <div className="p-4 sm:p-5 rounded-2xl border border-industrial-border bg-white shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-50 border border-amber-200 text-amber-600">
                <Lightbulb className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-sm font-bold text-industrial-textDark font-mono uppercase">
                  Ring LED Light Control
                </h2>
                <p className="text-xs text-industrial-textMuted">High-CRI Polarization Ring Illuminator</p>
              </div>
            </div>

            <span
              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-mono font-bold ${
                ledState
                  ? 'bg-amber-50 border border-amber-200 text-amber-700'
                  : 'bg-slate-100 text-slate-600'
              }`}
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  ledState ? 'bg-amber-500 shadow-[0_0_6px_#fbbf24]' : 'bg-slate-400'
                }`}
              />
              {ledState ? 'ON' : 'OFF'}
            </span>
          </div>

          {/* Brightness Slider */}
          <div className="space-y-2 p-3.5 rounded-xl bg-slate-50 border border-industrial-border">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-industrial-textDark font-semibold">Brightness Level:</span>
              <span className="text-amber-700 font-bold text-sm">{brightness}%</span>
            </div>

            <input
              type="range"
              min="0"
              max="100"
              value={brightness}
              onChange={(e) => handleBrightnessChange(Number(e.target.value))}
              className="w-full h-2.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />

            <div className="flex justify-between text-[10px] font-mono text-industrial-textMuted">
              <span>0% (OFF)</span>
              <span>50%</span>
              <span>100% (MAX)</span>
            </div>
          </div>

          {/* Power Controls */}
          <div className="grid grid-cols-2 gap-2.5">
            <button
              onClick={() => handleToggleLED(true)}
              className={`py-2.5 px-3 rounded-xl font-mono text-xs font-bold transition flex items-center justify-center gap-2 ${
                ledState
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'bg-white border border-industrial-border text-industrial-textDark hover:bg-slate-50'
              }`}
            >
              <Power className="w-3.5 h-3.5" />
              <span>LED ON</span>
            </button>

            <button
              onClick={() => handleToggleLED(false)}
              className={`py-2.5 px-3 rounded-xl font-mono text-xs font-bold transition flex items-center justify-center gap-2 ${
                !ledState
                  ? 'bg-rose-600 text-white shadow-sm'
                  : 'bg-white border border-industrial-border text-industrial-textDark hover:bg-slate-50'
              }`}
            >
              <Power className="w-3.5 h-3.5" />
              <span>LED OFF</span>
            </button>
          </div>
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
