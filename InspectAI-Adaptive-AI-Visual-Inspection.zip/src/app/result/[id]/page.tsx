'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Header } from '@/components/Header';
import { BottomNav } from '@/components/BottomNav';
import { apiService } from '@/services/apiService';
import { InspectionRecord } from '@/lib/types';
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ArrowLeft,
  Share2,
  Bookmark,
  Calendar,
  Clock,
  Cpu,
  Layers,
  Sparkles,
  ShieldCheck,
  Zap,
} from 'lucide-react';

export default function ResultDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [inspection, setInspection] = useState<InspectionRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    async function load() {
      const data = await apiService.getInspectionDetails(params.id);
      if (data) {
        setInspection(data);
      } else {
        const latest = await apiService.getLatestInspection();
        setInspection(latest);
      }
      setLoading(false);
    }
    load();
  }, [params.id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-industrial-bg text-industrial-textDark flex items-center justify-center">
        <div className="flex flex-col items-center gap-2">
          <Cpu className="w-8 h-8 text-blue-600 animate-spin" />
          <span className="text-xs font-mono text-industrial-textMuted font-semibold">Loading inspection verdict...</span>
        </div>
      </div>
    );
  }

  if (!inspection) {
    return (
      <div className="min-h-screen bg-industrial-bg text-industrial-textDark flex flex-col items-center justify-center p-4">
        <AlertTriangle className="w-12 h-12 text-amber-500 mb-2" />
        <h2 className="text-lg font-bold">Inspection Record Not Found</h2>
        <button
          onClick={() => router.push('/history')}
          className="mt-4 px-4 py-2 rounded-xl bg-blue-600 text-xs font-mono text-white font-bold"
        >
          Return to History
        </button>
      </div>
    );
  }

  const isPass = inspection.result === 'PASS';
  const timeStr = new Date(inspection.timestamp).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });
  const dateStr = new Date(inspection.timestamp).toLocaleDateString([], {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `InspectAI Result - ${inspection.productId}`,
        text: `Inspection ${inspection.inspectionId}: ${inspection.result} (${inspection.defect}, ${(inspection.confidence * 100).toFixed(1)}%)`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      alert(`Inspection Report Copied to Clipboard:\nID: ${inspection.inspectionId}\nStatus: ${inspection.result}\nConfidence: ${(inspection.confidence * 100).toFixed(1)}%`);
    }
  };

  const handleSave = () => {
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="min-h-screen bg-industrial-bg text-industrial-textDark pb-24 selection:bg-blue-600/10 selection:text-blue-600">
      <Header />

      <main className="max-w-2xl mx-auto px-4 py-4 space-y-4">
        {/* Navigation back bar */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => router.back()}
            className="flex items-center gap-1.5 text-xs font-mono text-industrial-textMuted hover:text-industrial-textDark font-semibold transition"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </button>
          <span className="text-xs font-mono text-industrial-textMuted font-bold">
            {inspection.inspectionId}
          </span>
        </div>

        {/* Inspected Product Image with AI Bounding Box */}
        <div className="relative aspect-[16/10] sm:aspect-[16/9] w-full rounded-2xl overflow-hidden border border-industrial-border bg-slate-950 shadow-md">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={inspection.imageUrl}
            alt="AI Visual Inspection Result"
            className="w-full h-full object-cover"
          />

          <div className="absolute bottom-2 left-2 px-2.5 py-1 rounded bg-slate-950/80 backdrop-blur-md border border-slate-700/60 text-[10px] font-mono text-slate-300">
            Optic: 1920x1080 • Overlay: Active
          </div>
        </div>

        {/* Main Verdict Card */}
        <div
          className={`p-5 rounded-2xl border ${
            isPass
              ? 'bg-emerald-50 border-emerald-300'
              : 'bg-rose-50 border-rose-300'
          } shadow-sm flex items-center justify-between`}
        >
          <div className="flex items-center gap-3.5">
            <div
              className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                isPass ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20' : 'bg-rose-600 text-white shadow-md shadow-rose-600/20'
              }`}
            >
              {isPass ? <CheckCircle2 className="w-7 h-7" /> : <XCircle className="w-7 h-7" />}
            </div>

            <div>
              <span className="text-[11px] font-mono uppercase text-industrial-textMuted tracking-wider font-semibold">
                Inspection Verdict
              </span>
              <h2
                className={`text-2xl font-black tracking-tight ${
                  isPass ? 'text-emerald-700' : 'text-rose-700'
                }`}
              >
                {inspection.result}
              </h2>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[11px] font-mono text-industrial-textMuted block font-semibold">AI Confidence</span>
            <span className="text-xl font-black text-industrial-textDark font-mono">
              {(inspection.confidence * 100).toFixed(1)}%
            </span>
          </div>
        </div>

        {/* Telemetry Metadata Grid */}
        <div className="p-4 sm:p-5 rounded-2xl border border-industrial-border bg-white shadow-sm space-y-3">
          <h3 className="text-xs font-mono uppercase text-industrial-textMuted font-bold tracking-wider">
            Inspection Telemetry & Analysis
          </h3>

          <div className="grid grid-cols-2 gap-3 text-xs font-mono">
            <div className="p-2.5 rounded-xl bg-slate-50 border border-industrial-border">
              <span className="text-industrial-textMuted block text-[11px]">Product ID</span>
              <span className="font-bold text-industrial-textDark">{inspection.productId}</span>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-industrial-border">
              <span className="text-industrial-textMuted block text-[11px]">Inspection ID</span>
              <span className="font-bold text-industrial-textDark truncate block">{inspection.inspectionId}</span>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-industrial-border">
              <span className="text-industrial-textMuted block text-[11px]">Date</span>
              <span className="font-bold text-industrial-textDark">{dateStr}</span>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-industrial-border">
              <span className="text-industrial-textMuted block text-[11px]">Time</span>
              <span className="font-bold text-industrial-textDark">{timeStr}</span>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-industrial-border">
              <span className="text-industrial-textMuted block text-[11px]">Defect Class</span>
              <span className={`font-bold ${isPass ? 'text-emerald-700' : 'text-rose-700'}`}>
                {inspection.defect}
              </span>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-industrial-border">
              <span className="text-industrial-textMuted block text-[11px]">Defect Location</span>
              <span className="font-bold text-industrial-textDark">{inspection.location}</span>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-industrial-border">
              <span className="text-industrial-textMuted block text-[11px]">Severity</span>
              <span
                className={`font-bold ${
                  inspection.severity === 'CRITICAL' || inspection.severity === 'HIGH'
                    ? 'text-rose-700'
                    : inspection.severity === 'MEDIUM'
                    ? 'text-amber-700'
                    : 'text-emerald-700'
                }`}
              >
                {inspection.severity}
              </span>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-industrial-border">
              <span className="text-industrial-textMuted block text-[11px]">Neural Model</span>
              <span className="font-bold text-industrial-textDark truncate block">{inspection.model}</span>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-industrial-border col-span-2">
              <span className="text-industrial-textMuted block text-[11px]">Inference Latency</span>
              <span className="font-bold text-industrial-textDark">{inspection.processingTimeMs} ms (Edge Accelerated)</span>
            </div>
          </div>

          {inspection.notes && (
            <div className="p-3 rounded-xl bg-slate-50 border border-industrial-border text-xs text-industrial-textDark space-y-1">
              <span className="text-[11px] font-mono text-industrial-textMuted uppercase block font-bold">
                AI Diagnostic Notes
              </span>
              <p>{inspection.notes}</p>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-2.5">
          <button
            onClick={handleSave}
            className="py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 font-bold text-xs font-mono text-white flex items-center justify-center gap-2 shadow-sm transition"
          >
            <Bookmark className="w-4 h-4" />
            <span>{savedSuccess ? 'RECORD SAVED!' : 'SAVE RESULT'}</span>
          </button>

          <button
            onClick={handleShare}
            className="py-3 px-4 rounded-xl bg-white hover:bg-slate-50 active:bg-slate-100 border border-industrial-border font-bold text-xs font-mono text-industrial-textDark flex items-center justify-center gap-2 shadow-sm transition"
          >
            <Share2 className="w-4 h-4 text-blue-600" />
            <span>SHARE REPORT</span>
          </button>
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
