'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Header } from '@/components/Header';
import { BottomNav } from '@/components/BottomNav';
import { CameraPreview } from '@/components/CameraPreview';
import { apiService } from '@/services/apiService';
import { InspectionRecord, ProductItem } from '@/lib/types';
import {
  Play,
  Camera,
  Layers,
  Sparkles,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ArrowRight,
  Clock,
  Cpu,
  RefreshCw,
} from 'lucide-react';

export default function LiveInspectionPage() {
  const router = useRouter();

  const [products, setProducts] = useState<ProductItem[]>([]);
  const [selectedProductId, setSelectedProductId] = useState('PCB-001');
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeStep, setActiveStep] = useState<string>('Ready for inspection');
  const [currentResult, setCurrentResult] = useState<InspectionRecord | null>(null);
  const [liveImage, setLiveImage] = useState<string>('');

  useEffect(() => {
    async function init() {
      const prods = await apiService.getProducts();
      setProducts(prods);
      const latest = await apiService.getLatestInspection();
      if (latest) {
        setCurrentResult(latest);
        setLiveImage(latest.imageUrl);
      }
    }
    init();
  }, []);

  const handleStartInspection = async () => {
    if (isProcessing) return;
    setIsProcessing(true);

    setActiveStep('1. Sending trigger signal to ESP32 & Industrial Camera Optic...');
    await new Promise((r) => setTimeout(r, 600));

    setActiveStep('2. Edge Computer: Running OpenCV noise reduction & CLAHE enhancement...');
    await new Promise((r) => setTimeout(r, 600));

    setActiveStep('3. Deep Learning: Running YOLO Defect Detector inference...');
    await new Promise((r) => setTimeout(r, 700));

    try {
      const response = await apiService.startInspection(selectedProductId);
      if (response.success && response.result) {
        setCurrentResult(response.result);
        setLiveImage(response.result.imageUrl);
        setActiveStep('Inspection complete!');
      }
    } catch (err) {
      console.error(err);
      setActiveStep('Inspection failed - check edge device network.');
    } finally {
      setIsProcessing(false);
    }
  };

  const isPass = currentResult?.result === 'PASS';

  return (
    <div className="min-h-screen bg-industrial-bg text-industrial-textDark pb-24 selection:bg-blue-600/10 selection:text-blue-600">
      <Header />

      <main className="max-w-2xl mx-auto px-4 py-4 space-y-4">
        {/* Top Connection Status */}
        <div className="flex items-center justify-between px-1 text-xs font-mono text-industrial-textMuted">
          <div className="flex items-center gap-2">
            <span>Machine: <strong className="text-industrial-textDark font-bold">Inspection Unit - 01</strong></span>
          </div>
          <div className="flex items-center gap-1.5 text-emerald-700 font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_6px_#10b981]" />
            <span>Connected</span>
          </div>
        </div>

        {/* Product SKU Selector */}
        <div className="p-3 rounded-xl border border-industrial-border bg-white shadow-sm flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-blue-600" />
            <span className="text-xs font-mono text-industrial-textDark font-bold">Target SKU:</span>
          </div>

          <select
            value={selectedProductId}
            onChange={(e) => setSelectedProductId(e.target.value)}
            disabled={isProcessing}
            className="px-3 py-1.5 rounded-lg bg-slate-50 border border-industrial-border text-xs font-mono text-industrial-textDark focus:outline-none focus:ring-1 focus:ring-blue-600"
          >
            {products.map((p) => (
              <option key={p.productId} value={p.productId}>
                {p.productId} - {p.name}
              </option>
            ))}
          </select>
        </div>

        {/* Optical Vision Viewport */}
        <CameraPreview
          imageUrl={liveImage}
          isProcessing={isProcessing}
          resolution="1920 x 1080"
          fps={24}
          defectLabel={currentResult ? (isPass ? `Normal ${(currentResult.confidence * 100).toFixed(1)}%` : `${currentResult.defect} ${(currentResult.confidence * 100).toFixed(1)}%`) : undefined}
          isPass={isPass}
        />

        {/* Processing State Banner */}
        {isProcessing && (
          <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-blue-800 text-xs font-mono flex items-center gap-2.5 animate-pulse font-semibold">
            <Cpu className="w-4 h-4 text-blue-600 animate-spin" />
            <span>{activeStep}</span>
          </div>
        )}

        {/* Action Controls */}
        <div className="grid grid-cols-3 gap-2.5">
          <button
            onClick={handleStartInspection}
            disabled={isProcessing}
            className="col-span-2 py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 font-bold text-sm text-white shadow-md shadow-blue-600/20 flex items-center justify-center gap-2 transition disabled:opacity-50 font-mono uppercase"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>START INSPECTION</span>
          </button>

          <button
            onClick={handleStartInspection}
            disabled={isProcessing}
            className="py-3.5 px-3 rounded-xl bg-white hover:bg-slate-50 border border-industrial-border text-xs font-mono text-industrial-textDark font-bold flex items-center justify-center gap-1.5 transition disabled:opacity-50 shadow-sm"
          >
            <Camera className="w-4 h-4 text-blue-600" />
            <span>CAPTURE</span>
          </button>
        </div>

        {/* Result Preview Banner */}
        {currentResult && !isProcessing && (
          <div
            onClick={() => router.push(`/result/${currentResult.id}`)}
            className={`p-4 rounded-2xl border transition-all cursor-pointer active:scale-[0.99] shadow-sm ${
              isPass
                ? 'bg-emerald-50/70 border-emerald-300 hover:border-emerald-400'
                : 'bg-rose-50/70 border-rose-300 hover:border-rose-400'
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span
                    className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-black font-mono tracking-wider ${
                      isPass
                        ? 'bg-emerald-600 text-white'
                        : 'bg-rose-600 text-white'
                    }`}
                  >
                    {isPass ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                    ) : (
                      <XCircle className="w-3.5 h-3.5 text-white" />
                    )}
                    {currentResult.result}
                  </span>
                  <span className="font-mono text-xs font-bold text-industrial-textDark">
                    {currentResult.productId}
                  </span>
                </div>

                <p className="text-sm font-bold text-industrial-textDark pt-1">
                  {isPass ? 'Zero Defect Discrepancies' : `Defect Detected: ${currentResult.defect}`}
                </p>

                <div className="flex items-center gap-3 text-xs font-mono text-industrial-textMuted">
                  <span>Confidence: <strong className="text-industrial-textDark">{(currentResult.confidence * 100).toFixed(1)}%</strong></span>
                  <span>•</span>
                  <span>Latency: <strong className="text-industrial-textDark">{currentResult.processingTimeMs} ms</strong></span>
                </div>
              </div>

              <div className="flex items-center gap-1 text-xs font-mono text-blue-700 font-bold pt-1">
                <span>View Full Verdict</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
}
