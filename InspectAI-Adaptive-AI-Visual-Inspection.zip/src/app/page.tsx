'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import {
  Cpu,
  Lock,
  Mail,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Activity,
  Camera,
  Layers,
  Sparkles,
  Database,
} from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const { login, demoLogin, loading } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!email || !password) {
      setErrorMessage('Please provide both email and password.');
      return;
    }

    setIsSubmitting(true);
    const res = await login(email, password);
    setIsSubmitting(false);

    if (res.success) {
      router.push('/dashboard');
    } else {
      setErrorMessage(res.error || 'Authentication failed.');
    }
  };

  const handleDemoClick = async (role: 'ADMIN' | 'OPERATOR' | 'VIEWER' = 'ADMIN') => {
    setIsSubmitting(true);
    await demoLogin(role);
    setIsSubmitting(false);
    router.push('/dashboard');
  };

  return (
    <div className="min-h-screen bg-industrial-bg text-industrial-textDark flex flex-col justify-between selection:bg-blue-600/10 selection:text-blue-600">
      {/* Top Banner */}
      <header className="px-6 py-4 flex items-center justify-between border-b border-industrial-border bg-white shadow-sm">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-sm">
            <Cpu className="w-4 h-4" />
          </div>
          <div>
            <span className="font-extrabold text-sm tracking-tight text-industrial-textDark">InspectAI</span>
            <span className="text-[10px] font-mono text-blue-600 block leading-none font-semibold">
              Adaptive Visual Inspection Platform
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-[11px] font-mono text-emerald-700 font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_6px_#10b981]" />
            Unit-01 Online
          </span>
        </div>
      </header>

      {/* Main Login Card */}
      <main className="flex-1 max-w-md w-full mx-auto px-4 py-8 flex flex-col justify-center">
        <div className="p-6 sm:p-8 rounded-2xl border border-industrial-border bg-white shadow-md space-y-6">
          {/* Logo & Headline */}
          <div className="text-center space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-mono font-bold">
              <Activity className="w-3.5 h-3.5 text-blue-600" />
              <span>Synthetic AI & Computer Vision Node</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-industrial-textDark tracking-tight">
              Sign In to InspectAI
            </h1>
            <p className="text-xs sm:text-sm text-industrial-textMuted">
              Adaptive AI visual inspection system for automated manufacturing quality control.
            </p>
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium">
              {errorMessage}
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-mono text-industrial-textDark font-semibold mb-1.5">
                Operator Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-industrial-textMuted absolute left-3 top-3" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@inspectai.com"
                  className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm rounded-xl border border-industrial-border bg-slate-50 text-industrial-textDark placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white font-mono transition"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-mono text-industrial-textDark font-semibold">Password</label>
                <button
                  type="button"
                  onClick={() => alert('For prototype demonstration, use the instant Demo Access buttons below.')}
                  className="text-[11px] text-blue-600 hover:underline font-medium"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-industrial-textMuted absolute left-3 top-3" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm rounded-xl border border-industrial-border bg-slate-50 text-industrial-textDark placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white font-mono transition"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 font-bold text-xs sm:text-sm text-white shadow-md shadow-blue-600/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isSubmitting ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <span>Sign In to System</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Quick Demo Login Preset Buttons */}
          <div className="pt-4 border-t border-industrial-border space-y-3">
            <div className="text-center">
              <span className="text-[11px] font-mono uppercase text-industrial-textMuted font-bold tracking-wider">
                Instant Demo Access (No Setup Required)
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => handleDemoClick('ADMIN')}
                className="py-2 px-2 rounded-xl bg-blue-50 hover:bg-blue-100 border border-blue-200 text-[11px] font-mono text-blue-700 transition text-center font-bold"
              >
                Admin Mode
              </button>
              <button
                type="button"
                onClick={() => handleDemoClick('OPERATOR')}
                className="py-2 px-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-[11px] font-mono text-emerald-700 transition text-center font-bold"
              >
                Operator
              </button>
              <button
                type="button"
                onClick={() => handleDemoClick('VIEWER')}
                className="py-2 px-2 rounded-xl bg-purple-50 hover:bg-purple-100 border border-purple-200 text-[11px] font-mono text-purple-700 transition text-center font-bold"
              >
                Viewer
              </button>
            </div>

            <div className="text-center text-[11px] text-industrial-textMuted font-mono">
              Demo user: <strong className="text-industrial-textDark">admin@inspectai.com</strong> / <strong className="text-industrial-textDark">admin123</strong>
            </div>
          </div>
        </div>

        {/* Feature badges */}
        <div className="mt-6 grid grid-cols-3 gap-2 text-center text-[10px] font-mono text-industrial-textMuted">
          <div className="p-2 rounded-xl bg-white border border-industrial-border shadow-sm">
            <Camera className="w-3.5 h-3.5 mx-auto text-blue-600 mb-1" />
            <span className="font-semibold text-industrial-textDark">50mm Optic</span>
          </div>
          <div className="p-2 rounded-xl bg-white border border-industrial-border shadow-sm">
            <Cpu className="w-3.5 h-3.5 mx-auto text-emerald-600 mb-1" />
            <span className="font-semibold text-industrial-textDark">YOLOv8 Core</span>
          </div>
          <div className="p-2 rounded-xl bg-white border border-industrial-border shadow-sm">
            <Database className="w-3.5 h-3.5 mx-auto text-amber-600 mb-1" />
            <span className="font-semibold text-industrial-textDark">Synthetic Data</span>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="px-6 py-3 border-t border-industrial-border bg-white text-center text-xs text-industrial-textMuted font-mono">
        InspectAI • Low-Cost Adaptive AI Visual Inspection System © 2026
      </footer>
    </div>
  );
}
