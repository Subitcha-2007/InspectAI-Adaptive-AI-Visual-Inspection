'use client';

import React, { useState, useEffect } from 'react';
import { Header } from '@/components/Header';
import { BottomNav } from '@/components/BottomNav';
import { QualityReportModal } from '@/components/QualityReportModal';
import { apiService } from '@/services/apiService';
import { AnalyticsData, SettingsData } from '@/lib/types';
import { ReportGenerationParams } from '@/lib/pdfGenerator';
import {
  BarChart3,
  TrendingUp,
  CheckCircle2,
  XCircle,
  FileText,
  Share2,
  Download,
  Percent,
  Clock,
  Sparkles,
  PieChart,
} from 'lucide-react';

export default function AnalyticsPage() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [settings, setSettings] = useState<SettingsData | null>(null);
  const [reportRange, setReportRange] = useState<'Daily' | 'Weekly' | 'Monthly'>('Daily');
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const [anaRes, setRes] = await Promise.all([
          apiService.getAnalytics(),
          apiService.getSettings(),
        ]);
        setData(anaRes);
        setSettings(setRes);
      } catch (err) {
        console.error('Failed to load analytics:', err);
      } finally {
        setIsLoading(false);
      }
    }
    load();
  }, []);

  const total = data?.totalInspections !== undefined ? data.totalInspections : 29;
  const pass = data?.passCount !== undefined ? data.passCount : 22;
  const fail = data?.failCount !== undefined ? data.failCount : 7;
  const passRate = total > 0 ? Number(((pass / total) * 100).toFixed(1)) : 0;
  const failRate = total > 0 ? Number(((fail / total) * 100).toFixed(1)) : 0;
  const avgLatency = data?.avgProcessingTimeMs || 174;
  const avgConfidence = data?.avgConfidence || 94.2;

  const defectSummary = (data?.defectDistribution || []).map((d) => ({
    type: d.type,
    count: d.count,
    percentage: d.percentage,
  }));

  const reportParams: ReportGenerationParams = {
    reportPeriod: reportRange,
    totalInspected: total,
    passed: pass,
    failed: fail,
    passRate: passRate,
    avgLatencyMs: avgLatency,
    avgConfidence: avgConfidence,
    defectSummary: defectSummary,
    systemMode: settings?.systemMode === 'LIVE' ? 'Live Hardware Mode' : 'Demo Mode (Simulation)',
    backendStatus: 'OPERATIONAL (200 OK)',
    aiModel: settings?.modelName || 'YOLOv8-Inspection-Custom (Edge ONNX)',
    qualityThreshold: 75.0,
  };

  const handleOpenReport = () => {
    setIsReportModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-industrial-bg text-industrial-textDark pb-24 selection:bg-blue-600/10 selection:text-blue-600">
      <Header />

      <main className="max-w-2xl mx-auto px-4 py-4 space-y-5">
        {/* Title */}
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[11px] font-mono text-industrial-textMuted uppercase tracking-wider font-semibold">
              Statistical Intelligence
            </span>
            <h1 className="text-xl font-black text-industrial-textDark">Quality Analytics</h1>
          </div>

          <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-industrial-border text-xs font-mono shadow-sm">
            {(['Daily', 'Weekly', 'Monthly'] as const).map((range) => (
              <button
                key={range}
                onClick={() => setReportRange(range)}
                className={`px-2.5 py-1 rounded-lg font-bold transition ${
                  reportRange === range
                    ? 'bg-blue-600 text-white'
                    : 'text-industrial-textMuted hover:text-industrial-textDark'
                }`}
              >
                {range}
              </button>
            ))}
          </div>
        </div>

        {/* 4 Metric Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="p-3.5 rounded-xl border border-industrial-border bg-white shadow-sm space-y-1">
            <span className="text-[11px] font-mono text-industrial-textMuted font-semibold block">Total Checked</span>
            <span className="text-xl sm:text-2xl font-black text-industrial-textDark font-mono">{total}</span>
            <span className="text-[10px] text-industrial-textMuted font-mono block">All active lines</span>
          </div>

          <div className="p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/50 shadow-sm space-y-1">
            <span className="text-[11px] font-mono text-emerald-700 font-bold block flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Pass Count
            </span>
            <span className="text-xl sm:text-2xl font-black text-emerald-700 font-mono">{pass}</span>
            <span className="text-[10px] text-emerald-600 font-mono block font-semibold">{passRate}% yield</span>
          </div>

          <div className="p-3.5 rounded-xl border border-rose-200 bg-rose-50/50 shadow-sm space-y-1">
            <span className="text-[11px] font-mono text-rose-700 font-bold block flex items-center gap-1">
              <XCircle className="w-3 h-3 text-rose-600" /> Fail Count
            </span>
            <span className="text-xl sm:text-2xl font-black text-rose-700 font-mono">{fail}</span>
            <span className="text-[10px] text-rose-600 font-mono block font-semibold">{failRate}% rejected</span>
          </div>

          <div className="p-3.5 rounded-xl border border-blue-200 bg-blue-50/50 shadow-sm space-y-1">
            <span className="text-[11px] font-mono text-blue-700 font-bold block flex items-center gap-1">
              <Clock className="w-3 h-3 text-blue-600" /> Avg Latency
            </span>
            <span className="text-xl sm:text-2xl font-black text-blue-900 font-mono">
              {avgLatency} ms
            </span>
            <span className="text-[10px] text-blue-600 font-mono block font-semibold">Edge YOLO Speed</span>
          </div>
        </div>

        {/* PASS vs FAIL Distribution Visual Breakdown */}
        <div className="p-4 sm:p-5 rounded-2xl border border-industrial-border bg-white shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-industrial-textDark font-mono uppercase">
              PASS vs FAIL Distribution
            </h2>
            <span className="text-xs font-mono text-emerald-700 font-bold">
              Yield: {passRate}%
            </span>
          </div>

          {/* Bar Chart Container */}
          <div className="w-full h-8 rounded-xl bg-slate-100 p-1 flex border border-industrial-border overflow-hidden">
            <div
              style={{ width: `${Math.max(2, passRate)}%` }}
              className="h-full bg-emerald-600 rounded-l-lg flex items-center justify-center text-[10px] font-bold text-white font-mono transition-all duration-500 shadow-sm"
            >
              PASS {passRate}%
            </div>
            <div
              style={{ width: `${Math.max(2, failRate)}%` }}
              className="h-full bg-rose-600 rounded-r-lg flex items-center justify-center text-[10px] font-bold text-white font-mono transition-all duration-500 shadow-sm"
            >
              FAIL {failRate}%
            </div>
          </div>

          <div className="flex items-center justify-between text-xs font-mono text-industrial-textMuted pt-1">
            <span className="flex items-center gap-1.5 font-medium">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              Passed: <strong className="text-industrial-textDark">{pass} Units</strong>
            </span>
            <span className="flex items-center gap-1.5 font-medium">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
              Rejected: <strong className="text-industrial-textDark">{fail} Units</strong>
            </span>
          </div>
        </div>

        {/* Defect Distribution by Class */}
        <div className="p-4 sm:p-5 rounded-2xl border border-industrial-border bg-white shadow-sm space-y-3">
          <h2 className="text-sm font-bold text-industrial-textDark font-mono uppercase">
            Defect Distribution by Type
          </h2>

          <div className="space-y-2.5">
            {(data?.defectDistribution || []).map((def) => (
              <div key={def.type} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-industrial-textDark font-semibold">{def.type}</span>
                  <span className="text-industrial-textMuted">
                    <strong className="text-industrial-textDark">{def.count}</strong> ({def.percentage}%)
                  </span>
                </div>

                <div className="w-full h-2.5 rounded-full bg-slate-100 overflow-hidden border border-slate-200">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${def.percentage}%`,
                      backgroundColor: def.color || '#DC2626',
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Daily Inspection Trend Bars */}
        <div className="p-4 sm:p-5 rounded-2xl border border-industrial-border bg-white shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-industrial-textDark font-mono uppercase">
              Daily Inspection Throughput
            </h2>
            <span className="text-xs font-mono text-industrial-textMuted font-medium">Past 5 Days</span>
          </div>

          <div className="grid grid-cols-5 gap-2 pt-2 items-end h-32">
            {(data?.dailyTrends || []).map((day) => {
              const heightPercent = Math.min(100, Math.max(20, (day.total / 70) * 100));
              return (
                <div key={day.date} className="flex flex-col items-center gap-1.5 h-full justify-end">
                  <span className="text-[10px] font-mono text-industrial-textDark font-bold">{day.total}</span>
                  <div
                    className="w-full bg-blue-600 hover:bg-blue-700 rounded-t-lg transition-all shadow-sm"
                    style={{ height: `${heightPercent}%` }}
                  />
                  <span className="text-[10px] font-mono text-industrial-textMuted font-medium">{day.date}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Automated Quality Report Action */}
        <div className="p-4 sm:p-5 rounded-2xl border border-blue-200 bg-blue-50/40 shadow-sm space-y-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-600 text-white">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-industrial-textDark font-mono">
                Executive Quality Report Generator
              </h3>
              <p className="text-xs text-industrial-textMuted">
                Generate printable report with dynamic defect clusters, AI latency, and compliance status.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              onClick={handleOpenReport}
              className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-xs font-mono font-bold text-white flex items-center justify-center gap-2 shadow-sm transition"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Generate Report</span>
            </button>
            <button
              onClick={() => {
                if (navigator.share) {
                  navigator.share({
                    title: 'InspectAI Quality Analytics',
                    text: `InspectAI Yield: ${passRate}% (${pass}/${total} units passed)`,
                    url: window.location.href,
                  }).catch(() => {});
                } else {
                  navigator.clipboard.writeText(window.location.href);
                  alert('Quality report URL copied to clipboard.');
                }
              }}
              className="py-2.5 px-3 rounded-xl bg-white hover:bg-slate-50 border border-industrial-border text-xs font-mono text-industrial-textDark font-bold flex items-center justify-center gap-2 shadow-sm transition"
            >
              <Share2 className="w-3.5 h-3.5 text-blue-600" />
              <span>Share Dashboard</span>
            </button>
          </div>
        </div>
      </main>

      {/* Quality Report Modal */}
      <QualityReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        reportParams={reportParams}
      />

      <BottomNav />
    </div>
  );
}
