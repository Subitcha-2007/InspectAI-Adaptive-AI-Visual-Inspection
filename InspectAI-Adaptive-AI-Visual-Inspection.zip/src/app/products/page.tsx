'use client';

import React, { useState, useEffect } from 'react';
import { Header } from '@/components/Header';
import { BottomNav } from '@/components/BottomNav';
import { apiService } from '@/services/apiService';
import { useAuth } from '@/context/AuthContext';
import { ProductItem } from '@/lib/types';
import {
  Layers,
  Plus,
  CheckCircle2,
  AlertTriangle,
  Cpu,
  ShieldCheck,
  Tag,
  Boxes,
} from 'lucide-react';

export default function ProductsPage() {
  const { role } = useAuth();
  const [products, setProducts] = useState<ProductItem[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newProdId, setNewProdId] = useState('');
  const [newProdName, setNewProdName] = useState('');
  const [newCategory, setNewCategory] = useState('Electronics / PCB');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const data = await apiService.getProducts();
      setProducts(data);
      setLoading(false);
    }
    load();
  }, []);

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdId || !newProdName) return;

    try {
      const created = await apiService.addProduct({
        productId: newProdId,
        name: newProdName,
        category: newCategory,
        status: 'ACTIVE',
        supportedDefects: 'Scratch, Crack, Missing Component, Wrong Component, Misalignment',
      });
      setProducts([...products, created]);
      setShowAddModal(false);
      setNewProdId('');
      setNewProdName('');
    } catch {
      alert('Failed to add product');
    }
  };

  return (
    <div className="min-h-screen bg-industrial-bg text-industrial-textDark pb-24 selection:bg-blue-600/10 selection:text-blue-600">
      <Header />

      <main className="max-w-2xl mx-auto px-4 py-4 space-y-4">
        {/* Title */}
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[11px] font-mono text-industrial-textMuted uppercase tracking-wider font-semibold">
              Inspection Catalog
            </span>
            <h1 className="text-xl font-black text-industrial-textDark">Supported Products</h1>
          </div>

          {role === 'ADMIN' && (
            <button
              onClick={() => setShowAddModal(true)}
              className="py-1.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-xs font-mono font-bold text-white flex items-center gap-1.5 transition shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add SKU</span>
            </button>
          )}
        </div>

        {/* Product Cards List */}
        <div className="space-y-3">
          {products.map((item) => (
            <div
              key={item.productId}
              className="p-4 sm:p-5 rounded-2xl border border-industrial-border bg-white shadow-sm space-y-3 hover:border-slate-300 transition"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-blue-700 px-2 py-0.5 rounded bg-blue-50 border border-blue-200">
                      {item.productId}
                    </span>
                    <span className="inline-flex items-center gap-1 text-[11px] font-mono text-emerald-700 font-bold">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      ACTIVE
                    </span>
                  </div>
                  <h2 className="text-base font-bold text-industrial-textDark mt-1">{item.name}</h2>
                  <p className="text-xs text-industrial-textMuted font-mono">{item.category}</p>
                </div>

                <div className="text-right font-mono">
                  <span className="text-[10px] text-industrial-textMuted uppercase block font-semibold">Inspected</span>
                  <span className="text-sm font-bold text-industrial-textDark">
                    {item.inspectionCount || 0} Units
                  </span>
                </div>
              </div>

              {/* Supported Defect Tags */}
              <div className="space-y-1.5 pt-2 border-t border-slate-100">
                <span className="text-[10px] font-mono text-industrial-textMuted uppercase tracking-wider block font-bold">
                  Trained AI Defect Classes:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {item.supportedDefects.split(',').map((d) => (
                    <span
                      key={d.trim()}
                      className="px-2 py-0.5 rounded-md bg-slate-50 border border-industrial-border text-[10px] font-mono text-industrial-textDark font-medium"
                    >
                      {d.trim()}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Add Product Modal */}
        {showAddModal && (
          <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="max-w-md w-full p-6 rounded-2xl border border-industrial-border bg-white shadow-xl space-y-4">
              <h3 className="text-base font-bold text-industrial-textDark font-mono">Add New Target Product</h3>
              <form onSubmit={handleAddProduct} className="space-y-3 text-xs font-mono">
                <div>
                  <label className="block text-industrial-textMuted mb-1 font-semibold">Product ID (SKU)</label>
                  <input
                    type="text"
                    required
                    value={newProdId}
                    onChange={(e) => setNewProdId(e.target.value)}
                    placeholder="e.g. PCB-005"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-industrial-border text-industrial-textDark font-mono focus:outline-none focus:ring-1 focus:ring-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-industrial-textMuted mb-1 font-semibold">Product Name</label>
                  <input
                    type="text"
                    required
                    value={newProdName}
                    onChange={(e) => setNewProdName(e.target.value)}
                    placeholder="e.g. Automotive Engine Sensor Board"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-industrial-border text-industrial-textDark font-mono focus:outline-none focus:ring-1 focus:ring-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-industrial-textMuted mb-1 font-semibold">Category</label>
                  <input
                    type="text"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-industrial-border text-industrial-textDark font-mono focus:outline-none focus:ring-1 focus:ring-blue-600"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="py-2.5 rounded-xl bg-slate-100 text-industrial-textDark font-bold hover:bg-slate-200"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="py-2.5 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-700 shadow-sm"
                  >
                    Create SKU
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
}
