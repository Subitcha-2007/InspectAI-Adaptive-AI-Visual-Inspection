'use client';

import React, { useState, useEffect } from 'react';
import { Header } from '@/components/Header';
import { BottomNav } from '@/components/BottomNav';
import {
  Database,
  Layers,
  Sparkles,
  Download,
  CheckCircle2,
  RefreshCw,
  Cpu,
  BarChart,
  Tag,
  Wand2,
} from 'lucide-react';

export default function SyntheticDatasetPage() {
  const [stats, setStats] = useState({
    total_images: 2400,
    normal_images: 800,
    synthetic_images: 1600,
    annotated_images: 2400,
    train_count: 1680,
    val_count: 480,
    test_count: 240,
    classes: ['Scratch', 'Crack', 'Missing Component', 'Wrong Component', 'Surface Defect', 'Misalignment'],
  });

  const [generating, setGenerating] = useState(false);
  const [sampleSize, setSampleSize] = useState(50);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleGenerate = async () => {
    setGenerating(true);
    await new Promise((r) => setTimeout(r, 1200));
    setStats((prev) => ({
      ...prev,
      total_images: prev.total_images + sampleSize,
      synthetic_images: prev.synthetic_images + sampleSize,
      annotated_images: prev.annotated_images + sampleSize,
    }));
    setGenerating(false);
    setSuccessMsg(`Successfully generated ${sampleSize} synthetic defect images with automated YOLO annotations!`);
    setTimeout(() => setSuccessMsg(null), 3500);
  };

  return (
    <div className="min-h-screen bg-industrial-bg text-industrial-textDark pb-24 selection:bg-blue-600/10 selection:text-blue-600">
      <Header />

      <main className="max-w-2xl mx-auto px-4 py-4 space-y-4">
        {/* Title */}
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[11px] font-mono text-industrial-textMuted uppercase tracking-wider font-semibold">
              Deep Learning Data Engine
            </span>
            <h1 className="text-xl font-black text-industrial-textDark">Synthetic Defect Dataset</h1>
          </div>
          <span className="px-2.5 py-1 rounded-full bg-amber-50 border border-amber-200 text-xs font-mono font-bold text-amber-700">
            Auto-Augmentation
          </span>
        </div>

        {successMsg && (
          <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-mono flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Dataset Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="p-3.5 rounded-xl border border-industrial-border bg-white shadow-sm space-y-1">
            <span className="text-[11px] font-mono text-industrial-textMuted font-semibold block">Total Dataset</span>
            <span className="text-xl sm:text-2xl font-black text-industrial-textDark font-mono">{stats.total_images}</span>
            <span className="text-[10px] text-industrial-textMuted font-mono block">Annotated Images</span>
          </div>

          <div className="p-3.5 rounded-xl border border-industrial-border bg-white shadow-sm space-y-1">
            <span className="text-[11px] font-mono text-emerald-700 font-bold block">Golden Masters</span>
            <span className="text-xl sm:text-2xl font-black text-emerald-700 font-mono">{stats.normal_images}</span>
            <span className="text-[10px] text-emerald-600 font-mono block">Zero-Defect Base</span>
          </div>

          <div className="p-3.5 rounded-xl border border-industrial-border bg-white shadow-sm space-y-1">
            <span className="text-[11px] font-mono text-amber-700 font-bold block">Synthetic Samples</span>
            <span className="text-xl sm:text-2xl font-black text-amber-700 font-mono">{stats.synthetic_images}</span>
            <span className="text-[10px] text-amber-600 font-mono block">Injected Defects</span>
          </div>

          <div className="p-3.5 rounded-xl border border-industrial-border bg-white shadow-sm space-y-1">
            <span className="text-[11px] font-mono text-blue-700 font-bold block">Train / Val Split</span>
            <span className="text-xl sm:text-2xl font-black text-blue-700 font-mono">70 / 20 / 10</span>
            <span className="text-[10px] text-blue-600 font-mono block">YOLO Format</span>
          </div>
        </div>

        {/* Synthetic Data Generator Action Box */}
        <div className="p-4 sm:p-5 rounded-2xl border border-industrial-border bg-white shadow-sm space-y-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-50 border border-amber-200 text-amber-600">
              <Wand2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-industrial-textDark font-mono uppercase">
                Generate Artificial Defect Augmentation
              </h2>
              <p className="text-xs text-industrial-textMuted">
                Generates mathematical scratches, missing pads, fractures & labels for YOLO retraining.
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-industrial-border">
            <span className="text-xs font-mono text-industrial-textDark font-semibold">Batch Samples:</span>
            <div className="flex items-center gap-1.5">
              {[25, 50, 100].map((sz) => (
                <button
                  key={sz}
                  onClick={() => setSampleSize(sz)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition ${
                    sampleSize === sz
                      ? 'bg-blue-600 text-white'
                      : 'bg-white border border-industrial-border text-industrial-textDark'
                  }`}
                >
                  +{sz}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handleGenerate}
            disabled={generating}
            className="w-full py-3 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 active:bg-amber-800 font-bold text-xs font-mono text-white shadow-md shadow-amber-600/20 flex items-center justify-center gap-2 transition disabled:opacity-50"
          >
            <Sparkles className="w-4 h-4" />
            <span>{generating ? 'GENERATING DEFECT SAMPLES...' : `GENERATE ${sampleSize} SYNTHETIC IMAGES`}</span>
          </button>
        </div>

        {/* Defect Classes Supported */}
        <div className="p-4 sm:p-5 rounded-2xl border border-industrial-border bg-white shadow-sm space-y-3">
          <h3 className="text-xs font-mono uppercase text-industrial-textMuted font-bold tracking-wider">
            Trained Defect Augmentation Classes
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {stats.classes.map((cls) => (
              <div key={cls} className="p-2.5 rounded-xl bg-slate-50 border border-industrial-border flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-industrial-textDark">{cls}</span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-emerald-100 text-emerald-800 font-bold">
                  Active
                </span>
              </div>
            ))}
          </div>
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
