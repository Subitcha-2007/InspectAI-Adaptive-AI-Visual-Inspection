'use client';

import React from 'react';
import Link from 'next/link';
import { useAuth } from '@/context/AuthContext';
import { ShieldCheck, Cpu, Wifi, Bell, User as UserIcon } from 'lucide-react';

interface HeaderProps {
  title?: string;
  subtitle?: string;
  showStatus?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  title,
  subtitle,
  showStatus = true,
}) => {
  const { user, role, switchRole } = useAuth();

  return (
    <header className="sticky top-0 z-40 px-4 py-3 bg-white/95 backdrop-blur-md border-b border-industrial-border shadow-sm">
      <div className="max-w-2xl mx-auto flex items-center justify-between">
        {/* Left: Brand / Title */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
            <Cpu className="w-5 h-5" />
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-base tracking-tight text-industrial-textDark">InspectAI</span>
              <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-blue-50 text-blue-700 border border-blue-200">
                PRO
              </span>
            </div>
            <p className="text-[11px] text-industrial-textMuted font-mono leading-none">
              Adaptive AI Visual Inspection
            </p>
          </div>
        </div>

        {/* Right: Machine status pill & Profile Role */}
        <div className="flex items-center gap-2">
          {showStatus && (
            <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-50 border border-slate-200 text-[11px] font-mono text-industrial-textDark">
              <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_6px_#10b981]" />
              <span>Unit 01</span>
            </div>
          )}

          {/* Role badge with switch menu */}
          <div className="relative group">
            <button className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-50 border border-slate-200 hover:bg-slate-100 text-xs font-medium text-industrial-textDark transition">
              <div className="w-2 h-2 rounded-full bg-blue-600" />
              <span className="font-mono text-[11px] font-bold uppercase">
                {role}
              </span>
            </button>

            {/* Quick role switch dropdown */}
            <div className="absolute right-0 mt-1 w-36 py-1 bg-white border border-industrial-border rounded-xl shadow-xl opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto transition-opacity z-50">
              <div className="px-3 py-1 text-[10px] font-mono uppercase text-industrial-textMuted border-b border-slate-100">
                Switch Role
              </div>
              <button
                onClick={() => switchRole('ADMIN')}
                className={`w-full text-left px-3 py-1.5 text-xs hover:bg-slate-50 font-medium ${
                  role === 'ADMIN' ? 'text-blue-600 font-bold bg-blue-50/50' : 'text-slate-700'
                }`}
              >
                ADMIN
              </button>
              <button
                onClick={() => switchRole('OPERATOR')}
                className={`w-full text-left px-3 py-1.5 text-xs hover:bg-slate-50 font-medium ${
                  role === 'OPERATOR' ? 'text-blue-600 font-bold bg-blue-50/50' : 'text-slate-700'
                }`}
              >
                OPERATOR
              </button>
              <button
                onClick={() => switchRole('VIEWER')}
                className={`w-full text-left px-3 py-1.5 text-xs hover:bg-slate-50 font-medium ${
                  role === 'VIEWER' ? 'text-blue-600 font-bold bg-blue-50/50' : 'text-slate-700'
                }`}
              >
                VIEWER
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
