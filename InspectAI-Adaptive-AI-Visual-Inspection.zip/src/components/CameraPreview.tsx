'use client';

import React, { useState, useEffect } from 'react';
import { Camera, RefreshCw, Crosshair, Zap, Cpu, Maximize2, Sparkles, Activity } from 'lucide-react';
import { BoundingBox } from '@/lib/types';

interface CameraPreviewProps {
  imageUrl?: string;
  isProcessing?: boolean;
  boundingBoxes?: BoundingBox[];
  resolution?: string;
  fps?: number;
  cameraStatus?: 'ONLINE' | 'OFFLINE';
  onTriggerInspection?: () => void;
  defectLabel?: string;
  isPass?: boolean;
}

export const CameraPreview: React.FC<CameraPreviewProps> = ({
  imageUrl,
  isProcessing = false,
  boundingBoxes = [],
  resolution = '1920 x 1080',
  fps = 24,
  cameraStatus = 'ONLINE',
  onTriggerInspection,
  defectLabel,
  isPass = true,
}) => {
  const [scanLinePos, setScanLinePos] = useState(0);

  // Scanline animation during active processing
  useEffect(() => {
    if (!isProcessing) return;
    const interval = setInterval(() => {
      setScanLinePos((prev) => (prev >= 100 ? 0 : prev + 4));
    }, 40);
    return () => clearInterval(interval);
  }, [isProcessing]);

  return (
    <div className="relative w-full rounded-2xl overflow-hidden border border-industrial-border bg-slate-900 shadow-md">
      {/* Top Industrial HUD overlay */}
      <div className="absolute top-0 left-0 right-0 z-20 px-4 py-2.5 bg-gradient-to-b from-slate-950/80 via-slate-950/30 to-transparent flex items-center justify-between pointer-events-none">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-white/90 backdrop-blur-md border border-slate-200 text-[11px] font-mono font-bold text-industrial-textDark shadow-sm">
            <span className={`w-2 h-2 rounded-full ${cameraStatus === 'ONLINE' ? 'bg-emerald-500 shadow-[0_0_6px_#10b981]' : 'bg-rose-500'}`} />
            CAM-01 • {resolution}
          </span>
          <span className="hidden sm:inline-flex items-center gap-1 px-2.5 py-0.5 rounded bg-white/90 backdrop-blur-md border border-slate-200 text-[11px] font-mono text-industrial-textMuted shadow-sm font-semibold">
            <Activity className="w-3 h-3 text-blue-600" />
            {fps} FPS
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-blue-600 text-white text-[11px] font-mono font-bold uppercase shadow-sm">
            <Zap className="w-3 h-3 text-white" />
            LIVE FEED
          </span>
        </div>
      </div>

      {/* Main Stream / Image Container */}
      <div className="relative aspect-[16/10] sm:aspect-[16/9] w-full bg-slate-950 flex items-center justify-center overflow-hidden select-none">
        {imageUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={imageUrl}
            alt="Physical Industrial Inspection Feed"
            className={`w-full h-full object-cover transition-all duration-300 ${
              isProcessing ? 'filter brightness-90 contrast-125' : ''
            }`}
          />
        ) : (
          <div className="flex flex-col items-center justify-center text-slate-500 gap-3">
            <Camera className="w-12 h-12 text-slate-600 animate-pulse" />
            <p className="text-xs font-mono font-medium">Initializing Industrial Optic Link...</p>
          </div>
        )}

        {/* Tactical Crosshairs */}
        <div className="absolute inset-0 pointer-events-none opacity-40">
          <div className="absolute top-4 left-4 w-6 h-6 border-t-2 border-l-2 border-blue-400" />
          <div className="absolute top-4 right-4 w-6 h-6 border-t-2 border-r-2 border-blue-400" />
          <div className="absolute bottom-4 left-4 w-6 h-6 border-b-2 border-l-2 border-blue-400" />
          <div className="absolute bottom-4 right-4 w-6 h-6 border-b-2 border-r-2 border-blue-400" />
        </div>

        {/* Center Reticle */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-30">
          <div className="w-24 h-24 border border-dashed border-blue-300 rounded-full" />
          <div className="absolute w-32 h-[1px] bg-blue-300" />
          <div className="absolute h-32 w-[1px] bg-blue-300" />
        </div>

        {/* Processing Scanning Beam */}
        {isProcessing && (
          <div
            className="absolute left-0 right-0 h-1.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_15px_#22d3ee] pointer-events-none z-30 transition-all ease-linear"
            style={{ top: `${scanLinePos}%` }}
          >
            <div className="absolute inset-0 bg-cyan-400/20 blur-sm -top-4 -bottom-4" />
          </div>
        )}

        {/* Processing Status Banner */}
        {isProcessing && (
          <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-[2px] z-30 flex flex-col items-center justify-center gap-3">
            <div className="relative">
              <div className="w-14 h-14 rounded-2xl bg-blue-600/30 border border-blue-400/50 flex items-center justify-center text-blue-400 animate-pulse">
                <Cpu className="w-7 h-7 animate-spin" />
              </div>
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
              </span>
            </div>
            <div className="text-center space-y-1">
              <p className="text-sm font-bold text-white tracking-wide font-mono">
                RUNNING AI DEFECT DETECTION
              </p>
              <p className="text-xs text-cyan-300 font-mono">
                YOLO Neural Inference • Feature Map Extraction...
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Bottom HUD info bar */}
      <div className="px-4 py-2.5 bg-white border-t border-industrial-border flex items-center justify-between text-xs font-mono">
        <div className="flex items-center gap-3">
          <span className="text-industrial-textMuted font-medium">
            STATUS:{' '}
            <span className={isProcessing ? 'text-blue-600 font-bold' : 'text-emerald-600 font-bold'}>
              {isProcessing ? 'PROCESSING' : 'READY'}
            </span>
          </span>
          <span className="text-slate-300 hidden sm:inline">|</span>
          <span className="text-industrial-textMuted hidden sm:inline">
            OPTIC: <span className="text-industrial-textDark font-semibold">50mm F/1.8 Industrial</span>
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] text-industrial-textMuted font-semibold">Adaptive Ring LED:</span>
          <span className="px-2 py-0.5 rounded bg-slate-100 text-industrial-textDark font-bold text-[11px] border border-slate-200">
            75%
          </span>
        </div>
      </div>
    </div>
  );
};
