import React from 'react';
import { InspectionRecord } from '@/lib/types';
import { CheckCircle2, XCircle, AlertTriangle } from 'lucide-react';

interface InspectionCardProps {
  inspection: InspectionRecord;
  onClick?: () => void;
  compact?: boolean;
}

export const InspectionCard: React.FC<InspectionCardProps> = ({
  inspection,
  onClick,
  compact = false,
}) => {
  const isPass = inspection.result === 'PASS';
  const timeStr = new Date(inspection.timestamp).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });
  const dateStr = new Date(inspection.timestamp).toLocaleDateString([], {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

  return (
    <div
      onClick={onClick}
      className={`group p-3.5 sm:p-4 rounded-xl border border-industrial-border bg-white hover:border-slate-300 hover:shadow-md transition-all duration-150 cursor-pointer active:scale-[0.99] relative overflow-hidden shadow-sm`}
    >
      {/* Accent side bar */}
      <div
        className={`absolute left-0 top-0 bottom-0 w-1.5 ${
          isPass ? 'bg-emerald-500' : 'bg-rose-500'
        }`}
      />

      <div className="flex items-start justify-between gap-3 pl-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <span className="font-mono text-xs font-bold text-industrial-textDark">
              {inspection.productId}
            </span>
            <span className="text-slate-300">•</span>
            <span className="text-[11px] font-mono text-industrial-textMuted">
              {inspection.inspectionId}
            </span>
          </div>

          <div className="flex items-center gap-2 text-xs text-industrial-textMuted">
            <span>{dateStr}</span>
            <span>{timeStr}</span>
          </div>

          {!isPass && (
            <div className="mt-2 flex items-center gap-2 flex-wrap">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-rose-50 border border-rose-200 text-rose-700">
                <AlertTriangle className="w-3 h-3 text-rose-600" />
                {inspection.defect}
              </span>
              {inspection.location !== 'None' && (
                <span className="text-[11px] text-industrial-textMuted font-mono">
                  loc: {inspection.location}
                </span>
              )}
            </div>
          )}
        </div>

        {/* Right side badge and confidence */}
        <div className="flex flex-col items-end gap-1.5">
          <div
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold ${
              isPass
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                : 'bg-rose-50 text-rose-700 border border-rose-200'
            }`}
          >
            {isPass ? (
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            ) : (
              <XCircle className="w-3.5 h-3.5 text-rose-600" />
            )}
            <span>{inspection.result}</span>
          </div>

          <div className="text-[11px] font-mono text-industrial-textMuted">
            <span>Conf: </span>
            <span className="font-bold text-industrial-textDark">
              {(inspection.confidence * 100).toFixed(1)}%
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
