import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatusCardProps {
  title: string;
  status: string;
  subtext?: string;
  icon: LucideIcon;
  variant?: 'camera' | 'ai' | 'led' | 'control' | 'default';
  isOnline?: boolean;
  onClick?: () => void;
}

export const StatusCard: React.FC<StatusCardProps> = ({
  title,
  status,
  subtext,
  icon: Icon,
  onClick,
}) => {
  const getStatusStyle = () => {
    const s = status.toUpperCase();
    if (s.includes('ONLINE') || s.includes('READY') || s.includes('ON') || s.includes('CONNECTED')) {
      return {
        dot: 'bg-emerald-500 shadow-[0_0_6px_rgba(16,185,129,0.4)]',
        text: 'text-emerald-700',
        badge: 'bg-emerald-50 border-emerald-200 text-emerald-700',
      };
    }
    if (s.includes('PROCESSING') || s.includes('WARNING') || s.includes('MAINTENANCE')) {
      return {
        dot: 'bg-amber-500 animate-ping',
        text: 'text-amber-700',
        badge: 'bg-amber-50 border-amber-200 text-amber-700',
      };
    }
    return {
      dot: 'bg-rose-500 shadow-[0_0_6px_rgba(244,63,94,0.4)]',
      text: 'text-rose-700',
      badge: 'bg-rose-50 border-rose-200 text-rose-700',
    };
  };

  const style = getStatusStyle();

  return (
    <div
      onClick={onClick}
      className={`p-3.5 sm:p-4 rounded-xl border border-industrial-border bg-white shadow-sm hover:shadow-md hover:border-slate-300 transition-all duration-200 ${
        onClick ? 'cursor-pointer active:scale-[0.98]' : ''
      }`}
    >
      <div className="flex items-center justify-between mb-2">
        <span className="text-[11px] font-mono tracking-wider font-semibold text-industrial-textMuted uppercase">
          {title}
        </span>
        <div className="p-1.5 rounded-lg bg-slate-50 text-blue-600 border border-slate-200">
          <Icon className="w-4 h-4" />
        </div>
      </div>

      <div className="flex items-center gap-2 mt-1">
        <span className={`w-2.5 h-2.5 rounded-full ${style.dot}`} />
        <span className={`text-sm sm:text-base font-bold tracking-tight ${style.text}`}>
          {status}
        </span>
      </div>

      {subtext && (
        <p className="text-[11px] text-industrial-textMuted mt-1 truncate font-mono">
          {subtext}
        </p>
      )}
    </div>
  );
};
