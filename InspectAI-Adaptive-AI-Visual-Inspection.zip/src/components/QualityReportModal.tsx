'use client';

import React from 'react';
import {
  X,
  Printer,
  Download,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Activity,
  Cpu,
  Camera,
  Layers,
  Sparkles,
} from 'lucide-react';
import { triggerPdfDownload, generateInspectAiPdfBlob, ReportGenerationParams } from '@/lib/pdfGenerator';
import { useToast } from '@/context/ToastContext';

interface QualityReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  reportParams: ReportGenerationParams;
}

export const QualityReportModal: React.FC<QualityReportModalProps> = ({
  isOpen,
  onClose,
  reportParams,
}) => {
  const { success, error } = useToast();

  if (!isOpen) return null;

  const {
    reportPeriod,
    totalInspected,
    passed,
    failed,
    passRate,
    avgLatencyMs,
    avgConfidence,
    defectSummary,
    systemMode,
    backendStatus,
    aiModel,
    qualityThreshold = 75.0,
  } = reportParams;

  const now = new Date();
  const dateStr = now.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
  });
  const timeStr = now.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  const isGood = passRate >= qualityThreshold;
  const qualityStatus = isGood ? 'QUALITY STATUS: GOOD' : 'QUALITY STATUS: ATTENTION REQUIRED';

  const handleDownloadPdf = () => {
    try {
      const blob = generateInspectAiPdfBlob(reportParams);
      const dateSuffix = new Date().toISOString().split('T')[0];
      const filename = `InspectAI_Quality_Report_${dateSuffix}.pdf`;
      triggerPdfDownload(blob, filename);
      success('Quality report downloaded successfully.');
    } catch (err: any) {
      console.error('Failed to generate PDF:', err);
      error('Unable to generate quality report. Please retry.');
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 print:p-0 print:bg-white print:static">
      <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-industrial-border overflow-hidden flex flex-col max-h-[92vh] print:max-h-none print:shadow-none print:border-none print:rounded-none">
        {/* Top Actions Bar (Hidden when printing) */}
        <div className="px-5 py-3.5 bg-slate-50 border-b border-industrial-border flex items-center justify-between no-print">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-blue-50 text-blue-600 border border-blue-200">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-xs sm:text-sm font-bold text-industrial-textDark font-mono">
                Executive Quality Inspection Report Preview
              </h2>
              <span className="text-[10px] text-industrial-textMuted font-mono">
                Generated {dateStr} at {timeStr}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadPdf}
              className="py-1.5 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-xs font-mono font-bold text-white shadow-sm flex items-center gap-1.5 transition"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download PDF</span>
            </button>
            <button
              onClick={handlePrint}
              className="py-1.5 px-3 rounded-lg bg-white hover:bg-slate-100 border border-industrial-border text-xs font-mono font-bold text-industrial-textDark shadow-sm flex items-center gap-1.5 transition"
            >
              <Printer className="w-3.5 h-3.5 text-blue-600" />
              <span>Print Report</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg hover:bg-slate-200 text-industrial-textMuted transition"
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Report Canvas */}
        <div id="printable-quality-report" className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-6 text-industrial-textDark print:p-0 print:overflow-visible">
          {/* Header Banner */}
          <div className="flex items-start justify-between border-b border-industrial-border pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md">
                <Cpu className="w-5 h-5" />
              </div>
              <div>
                <span className="text-lg font-black tracking-tight text-industrial-textDark uppercase font-mono">
                  INSPECTAI
                </span>
                <p className="text-xs text-blue-600 font-mono font-semibold">
                  AI-Powered Visual Quality Inspection Node
                </p>
              </div>
            </div>

            <div className="text-right font-mono space-y-0.5">
              <span className="text-xs font-bold uppercase text-industrial-textDark block">
                QUALITY INSPECTION REPORT
              </span>
              <span className="text-[11px] text-industrial-textMuted block">
                Report Period: <strong>{reportPeriod} Batch</strong>
              </span>
              <span className="text-[10px] text-industrial-textMuted block">
                Generated Date: {dateStr} {timeStr}
              </span>
            </div>
          </div>

          {/* Quality Status Pill */}
          <div
            className={`p-3 rounded-xl border flex items-center justify-between font-mono text-xs ${
              isGood
                ? 'bg-emerald-50/70 border-emerald-300 text-emerald-800'
                : 'bg-rose-50/70 border-rose-300 text-rose-800'
            }`}
          >
            <div className="flex items-center gap-2">
              {isGood ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              )}
              <span className="font-black tracking-wide uppercase">{qualityStatus}</span>
            </div>
            <span className="text-[11px] font-semibold">
              Pass Rate Target: {qualityThreshold}% Min
            </span>
          </div>

          {/* 1. Executive Summary */}
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-industrial-border pb-1">
              <h3 className="text-xs font-mono font-bold uppercase text-industrial-textDark tracking-wider">
                1. Executive Summary
              </h3>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl border border-industrial-border bg-slate-50">
                <span className="text-[10px] font-mono text-industrial-textMuted uppercase block">Total Inspected</span>
                <span className="text-xl font-black font-mono text-industrial-textDark">{totalInspected}</span>
                <span className="text-[10px] text-industrial-textMuted block font-mono">Units Checked</span>
              </div>
              <div className="p-3 rounded-xl border border-emerald-200 bg-emerald-50/50">
                <span className="text-[10px] font-mono text-emerald-700 uppercase block font-semibold">Passed</span>
                <span className="text-xl font-black font-mono text-emerald-700">{passed}</span>
                <span className="text-[10px] text-emerald-600 block font-mono">{passRate}% Yield</span>
              </div>
              <div className="p-3 rounded-xl border border-rose-200 bg-rose-50/50">
                <span className="text-[10px] font-mono text-rose-700 uppercase block font-semibold">Defects Flagged</span>
                <span className="text-xl font-black font-mono text-rose-700">{failed}</span>
                <span className="text-[10px] text-rose-600 block font-mono">{(100 - passRate).toFixed(1)}% Reject</span>
              </div>
              <div className="p-3 rounded-xl border border-blue-200 bg-blue-50/50">
                <span className="text-[10px] font-mono text-blue-700 uppercase block font-semibold">Avg AI Latency</span>
                <span className="text-xl font-black font-mono text-blue-900">{avgLatencyMs} ms</span>
                <span className="text-[10px] text-blue-600 block font-mono">Edge YOLO Speed</span>
              </div>
            </div>
          </div>

          {/* 2. Defect Summary Table */}
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-industrial-border pb-1">
              <h3 className="text-xs font-mono font-bold uppercase text-industrial-textDark tracking-wider">
                2. Defect Category Summary
              </h3>
              <span className="text-[11px] font-mono text-industrial-textMuted font-semibold">
                {defectSummary.length} Active Defect Classes
              </span>
            </div>

            <div className="border border-industrial-border rounded-xl overflow-hidden shadow-sm">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-100 text-industrial-textDark border-b border-industrial-border">
                  <tr>
                    <th className="py-2.5 px-3 font-bold uppercase text-[11px]">Defect Category</th>
                    <th className="py-2.5 px-3 font-bold uppercase text-[11px] text-center">Incidents</th>
                    <th className="py-2.5 px-3 font-bold uppercase text-[11px] text-center">Share</th>
                    <th className="py-2.5 px-3 font-bold uppercase text-[11px] text-right">Risk Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-industrial-border bg-white">
                  {defectSummary.length > 0 ? (
                    defectSummary.map((def, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/80">
                        <td className="py-2 px-3 font-medium text-industrial-textDark">{def.type}</td>
                        <td className="py-2 px-3 text-center text-rose-700 font-bold">{def.count}</td>
                        <td className="py-2 px-3 text-center text-industrial-textDark font-semibold">
                          {def.percentage.toFixed(1)}%
                        </td>
                        <td className="py-2 px-3 text-right">
                          <span className="px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200 text-[10px] font-bold">
                            REJECT / REWORK
                          </span>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={4} className="py-4 text-center text-industrial-textMuted">
                        No inspection defect incidents recorded.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* 3. Inspection Performance & System Telemetry */}
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-industrial-border pb-1">
              <h3 className="text-xs font-mono font-bold uppercase text-industrial-textDark tracking-wider">
                3. Inspection Performance & System Information
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
              <div className="p-3.5 rounded-xl border border-industrial-border bg-slate-50 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-industrial-textMuted">System Mode:</span>
                  <span className="font-bold text-industrial-textDark">{systemMode}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-industrial-textMuted">Hardware Controller:</span>
                  <span className="font-bold text-industrial-textDark">ESP32 IoT Node</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-industrial-textMuted">Optic System:</span>
                  <span className="font-bold text-industrial-textDark">50mm F/1.8 Low-Distortion Lens</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-industrial-textMuted">Lighting:</span>
                  <span className="font-bold text-industrial-textDark">PWM Ring LED (75% Calibrated)</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl border border-industrial-border bg-slate-50 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-industrial-textMuted">Backend Status:</span>
                  <span className="font-bold text-emerald-700">{backendStatus}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-industrial-textMuted">AI Model:</span>
                  <span className="font-bold text-blue-700">{aiModel}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-industrial-textMuted">Average Confidence:</span>
                  <span className="font-bold text-industrial-textDark">{avgConfidence}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-industrial-textMuted">Pass Rate Threshold:</span>
                  <span className="font-bold text-industrial-textDark">{qualityThreshold}%</span>
                </div>
              </div>
            </div>
          </div>

          {/* 4. Quality Sign-Off */}
          <div className="space-y-4 pt-2">
            <p className="text-[11px] text-industrial-textMuted font-mono">
              Generated automatically by the InspectAI system. Certified computer vision telemetry and bounding boxes stored in persistent ledger.
            </p>

            <div className="grid grid-cols-2 gap-8 pt-4">
              <div className="border-t border-slate-300 pt-1 font-mono text-[10px] text-industrial-textMuted">
                Lead Quality Inspector (Signature)
              </div>
              <div className="border-t border-slate-300 pt-1 font-mono text-[10px] text-industrial-textMuted text-right">
                Automated System Token: <strong className="text-industrial-textDark">SHA-256-AOI-CERT</strong>
              </div>
            </div>
          </div>

          {/* Footer */}
          <footer className="pt-4 border-t border-industrial-border flex items-center justify-between text-[10px] font-mono text-industrial-textMuted">
            <span>InspectAI • Adaptive AI Visual Inspection System</span>
            <span>Generated automatically by the InspectAI system.</span>
          </footer>
        </div>

        {/* Bottom Actions Bar (Hidden when printing) */}
        <div className="px-5 py-3 bg-slate-50 border-t border-industrial-border flex items-center justify-end gap-2.5 no-print">
          <button
            onClick={onClose}
            className="py-2 px-4 rounded-xl bg-white hover:bg-slate-100 border border-industrial-border text-xs font-mono font-bold text-industrial-textDark transition shadow-sm"
          >
            Close
          </button>
          <button
            onClick={handlePrint}
            className="py-2 px-4 rounded-xl bg-slate-200 hover:bg-slate-300 text-xs font-mono font-bold text-industrial-textDark flex items-center gap-1.5 transition shadow-sm"
          >
            <Printer className="w-3.5 h-3.5 text-blue-600" />
            <span>Print Report</span>
          </button>
          <button
            onClick={handleDownloadPdf}
            className="py-2 px-5 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-xs font-mono font-bold text-white flex items-center gap-1.5 transition shadow-md"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download PDF</span>
          </button>
        </div>
      </div>
    </div>
  );
};
