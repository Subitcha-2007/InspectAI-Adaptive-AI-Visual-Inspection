'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserRole } from '@/lib/types';
import { apiService } from '@/services/apiService';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  settings?: any;
}

interface AuthContextType {
  user: User | null;
  role: UserRole;
  loading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  demoLogin: (role?: UserRole) => Promise<void>;
  switchRole: (newRole: UserRole) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    async function loadInitialUser() {
      try {
        const res = await fetch('/api/auth/me');
        if (res.ok) {
          const data = await res.json();
          if (data.user) {
            setUser(data.user);
          }
        } else {
          // Default to demo operator session for immediate frictionless showcase
          const savedUser = localStorage.getItem('inspectai_active_user');
          if (savedUser) {
            setUser(JSON.parse(savedUser));
          } else {
            setUser({
              id: 'demo-admin-01',
              name: 'System Administrator',
              email: 'admin@inspectai.com',
              role: 'ADMIN',
              avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
            });
          }
        }
      } catch {
        setUser({
          id: 'demo-admin-01',
          name: 'System Administrator',
          email: 'admin@inspectai.com',
          role: 'ADMIN',
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        });
      } finally {
        setLoading(false);
      }
    }

    loadInitialUser();
  }, []);

  const login = async (email: string, password: string) => {
    setLoading(true);
    try {
      const res = await apiService.login(email, password);
      if (res.success && res.user) {
        setUser(res.user);
        localStorage.setItem('inspectai_active_user', JSON.stringify(res.user));
        setLoading(false);
        return { success: true };
      }
      setLoading(false);
      return { success: false, error: res.error || 'Invalid credentials' };
    } catch (err: any) {
      setLoading(false);
      return { success: false, error: err.message || 'Login failed' };
    }
  };

  const demoLogin = async (targetRole: UserRole = 'ADMIN') => {
    setLoading(true);
    let demoUser: User = {
      id: 'usr-admin-01',
      name: 'System Administrator',
      email: 'admin@inspectai.com',
      role: 'ADMIN',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    };

    if (targetRole === 'OPERATOR') {
      demoUser = {
        id: 'usr-op-01',
        name: 'Lead Operator Marcus',
        email: 'operator@inspectai.com',
        role: 'OPERATOR',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      };
    } else if (targetRole === 'VIEWER') {
      demoUser = {
        id: 'usr-vw-01',
        name: 'QA Inspector Sarah',
        email: 'viewer@inspectai.com',
        role: 'VIEWER',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
      };
    }

    setUser(demoUser);
    localStorage.setItem('inspectai_active_user', JSON.stringify(demoUser));
    setLoading(false);
  };

  const switchRole = (newRole: UserRole) => {
    if (user) {
      const updated = { ...user, role: newRole };
      setUser(updated);
      localStorage.setItem('inspectai_active_user', JSON.stringify(updated));
    }
  };

  const logout = async () => {
    await apiService.logout();
    setUser(null);
    localStorage.removeItem('inspectai_active_user');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        role: user?.role || 'OPERATOR',
        loading,
        login,
        logout,
        demoLogin,
        switchRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
