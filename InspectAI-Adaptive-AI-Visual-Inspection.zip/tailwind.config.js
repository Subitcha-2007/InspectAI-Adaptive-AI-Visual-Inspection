/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        industrial: {
          bg: '#F7F9FC',          // Light grey background
          card: '#FFFFFF',        // Pure white card surfaces
          cardElevated: '#F1F5F9',// Subtle elevation
          border: '#E2E8F0',      // Clean slate borders
          borderLight: '#EDF2F7', // Crisp dividers
          primary: '#2563EB',     // Professional primary blue
          primaryHover: '#1D4ED8',
          textDark: '#172033',    // High-contrast industrial dark text
          textMuted: '#64748B',   // Slate secondary text
          textLight: '#94A3B8',
          success: '#16A34A',     // Green for PASS
          danger: '#DC2626',      // Red for FAIL
          warning: '#F59E0B',     // Amber warnings
          info: '#0EA5E9',        // Cyan / Sky info
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'Consolas', 'Courier New', 'monospace'],
      },
    },
  },
  plugins: [],
};
