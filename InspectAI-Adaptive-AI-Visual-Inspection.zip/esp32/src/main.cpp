#include <WiFi.h>
#include <WebServer.h>
#include <ArduinoJson.h>

// Wi-Fi Credentials for Industrial Edge Network
const char* ssid = "INSPECTAI_WIFI_NODE";
const char* password = "InspectAIPassword2026";

WebServer server(80);

// Hardware Pin Assignments
const int PIN_RING_LED_PWM = 18; // MOSFET Gate / PWM LED driver
const int PIN_CAMERA_TRIGGER = 19; // Optocoupler trigger pulse to Industrial Camera
const int PIN_CONVEYOR_SENSOR = 21; // IR / Proximity sensor

// Peripheral States
bool ledState = true;
int ledBrightness = 75; // 0 - 100%
const int pwmChannel = 0;
const int pwmFreq = 5000;
const int pwmResolution = 8; // 8-bit (0-255)

void setLedPWM(bool state, int brightness) {
  ledState = state;
  ledBrightness = brightness;
  if (!state) {
    ledcWrite(pwmChannel, 0);
  } else {
    int dutyCycle = map(brightness, 0, 100, 0, 255);
    ledcWrite(pwmChannel, dutyCycle);
  }
}

void handleGetStatus() {
  StaticJsonDocument<256> doc;
  doc["status"] = "CONNECTED";
  doc["device_id"] = "INSPECT-UNIT-01";
  doc["ip_address"] = WiFi.localIP().toString();
  doc["wifi_rssi"] = WiFi.RSSI();
  doc["led_state"] = ledState ? "ON" : "OFF";
  doc["led_brightness"] = ledBrightness;
  doc["uptime_ms"] = millis();

  String response;
  serializeJson(doc, response);
  server.send(200, "application/json", response);
}

void handleSetLed() {
  if (server.hasArg("plain") == false) {
    server.send(400, "application/json", "{\"error\":\"Missing body\"}");
    return;
  }
  StaticJsonDocument<200> doc;
  deserializeJson(doc, server.arg("plain"));

  bool state = doc["state"] | true;
  int brightness = doc["brightness"] | 75;
  setLedPWM(state, brightness);

  StaticJsonDocument<200> resDoc;
  resDoc["success"] = true;
  resDoc["led"] = state ? "ON" : "OFF";
  resDoc["brightness"] = brightness;

  String response;
  serializeJson(resDoc, response);
  server.send(200, "application/json", response);
}

void handleCameraTrigger() {
  // Generate a clean 20ms TTL pulse to camera optocoupler
  digitalWrite(PIN_CAMERA_TRIGGER, HIGH);
  delay(20);
  digitalWrite(PIN_CAMERA_TRIGGER, LOW);

  server.send(200, "application/json", "{\"success\":true,\"message\":\"Camera frame capture triggered\"}");
}

void setup() {
  Serial.begin(115200);

  // Pin initialization
  pinMode(PIN_CAMERA_TRIGGER, OUTPUT);
  digitalWrite(PIN_CAMERA_TRIGGER, LOW);
  pinMode(PIN_CONVEYOR_SENSOR, INPUT_PULLUP);

  // PWM setup
  ledcSetup(pwmChannel, pwmFreq, pwmResolution);
  ledcAttachPin(PIN_RING_LED_PWM, pwmChannel);
  setLedPWM(true, 75);

  // Wi-Fi Connection
  WiFi.begin(ssid, password);
  Serial.print("Connecting to Industrial Wi-Fi Network");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nConnected! ESP32 IP: " + WiFi.localIP().toString());

  // REST API Routes
  server.on("/api/device/status", HTTP_GET, handleGetStatus);
  server.on("/api/device/led", HTTP_POST, handleSetLed);
  server.on("/api/device/camera-trigger", HTTP_POST, handleCameraTrigger);

  server.begin();
  Serial.println("InspectAI ESP32 HTTP Server Started.");
}

void loop() {
  server.handleClient();

  // Future conveyor belt IR trigger logic
  if (digitalRead(PIN_CONVEYOR_SENSOR) == LOW) {
    // Product detected on inspection bed
    delay(50); // Debounce
  }
}
