# InspectAI — Low-Cost Adaptive AI Visual Inspection System

> **Industrial Optical Inspection (AOI) & AI Quality Control Platform**  
> *Real-time monitoring, edge computer vision inference (YOLO), ESP32 hardware handshake, and lighting control for manufacturing defect detection.*

---

## 1. System Architecture & Data Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    PHYSICAL HARDWARE                        │
│  [ Product on Inspection Bed ] ───► [ Ring LED Light (PWM)] │
│                    │                                        │
│                    ▼                                        │
│         [ Industrial Camera Optic ]                         │
│                    │                                        │
│                    ▼                                        │
│        [ ESP32 Control Unit (Wi-Fi) ]                       │
└────────────────────┬────────────────────────────────────────┘
                     │ High-Res Image Stream & Wi-Fi REST
                     ▼
┌─────────────────────────────────────────────────────────────┐
│             EDGE COMPUTER / AI SERVER                       │
│  - Image Preprocessing & Optical Calibration                │
│  - Deep Learning Model (YOLO Defect Detector v8.4)          │
│  - Defect Classification & Bounding Box Generation          │
│  - PASS / FAIL Decision Matrix                              │
└────────────────────┬────────────────────────────────────────┘
                     │ JSON Verdict & HUD Telemetry
                     ▼
┌─────────────────────────────────────────────────────────────┐
│               REST BACKEND API LAYER                        │
│  - Machine Status: /api/device/status                       │
│  - LED Control: /api/device/led                             │
│  - Inspection: /api/inspection/start, /api/inspection/latest│
│  - Quality Analytics & History: /api/analytics, /history    │
└────────────────────┬────────────────────────────────────────┘
                     │ HTTPS / WebSockets / REST
                     ▼
┌─────────────────────────────────────────────────────────────┐
│             INSPECTAI MOBILE APPLICATION                    │
│  - Modern Industrial Dark UI (Tailwind CSS, Next.js 14)     │
│  - Real-Time Optical Viewport with Reticle HUD              │
│  - Dynamic AI Bounding Box Overlays                         │
│  - Hardware Control (Ring LED Slider, ESP32 Handshake)      │
│  - Quality Records, Defect Trends & Statistical Reports     │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Key Features

- **Industrial Dashboard**: Live machine status (`Inspection Unit - 01`), four peripheral indicators (Camera, AI Engine, Ring LED, ESP32 Control Unit), pass yield stats, and large tactical `START INSPECTION` trigger.
- **Real-Time Live Viewport (`/inspect`)**: HUD reticle with scanning beam animations, target SKU selector, and instant YOLO inference results.
- **Dedicated Inspection Verdict (`/result/[id]`)**: Full inspection telemetry (Product ID, Inspection ID, Defect Class, Severity, Location, Confidence %, Latency ms) with interactive share and save capabilities.
- **Supported Defect Classes**:
  1. Scratch
  2. Crack
  3. Missing Component
  4. Wrong Component
  5. Surface Defect
  6. Damaged Component
  7. Misalignment
  8. Unknown Defect
- **Hardware & ESP32 Control (`/hardware`)**: ESP32 connection telemetry, camera test runner, and dynamic 0%–100% Ring LED illumination slider.
- **Quality Analytics (`/analytics`)**: PASS vs FAIL ratio charts, defect distribution breakdowns, 5-day throughput volume, and automated Executive Quality Report generator.
- **Multi-Role Authentication**:
  - `ADMIN`: Full system configuration, hardware calibration, user management, and product SKU creation.
  - `OPERATOR`: Run inspections, machine trigger, view history and defect alerts.
  - `VIEWER`: Read-only access to quality dashboards and executive reports.
- **Zero-Dependency Demo Mode**: Works seamlessly both online with physical edge devices or in high-fidelity offline demonstration mode.

---

## 3. Demo Credentials

- **Admin Mode**: `admin@inspectai.com` / `admin123`
- **Operator Mode**: `operator@inspectai.com` / `operator123`
- **Viewer Mode**: `viewer@inspectai.com` / `viewer123`

---

## 4. Running the System

```bash
# 1. Install dependencies
npm install

# 2. Seed database with realistic industrial inspection records
npm run db:seed

# 3. Start application
npm run dev
```

InspectAI is accessible at `http://localhost:3000`.
